import React from 'react'

const AlertSuccessIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="54"
      height="54"
      viewBox="0 0 54 54">
      <path
        className="alert-success-icon"
        d="M36,9A27,27,0,1,0,63,36,27.028,27.028,0,0,0,36,9ZM50.758,27.709,32.319,46.148a1.3,1.3,0,0,1-1.857,0l-9.22-9.22A1.313,1.313,0,0,1,23.1,35.071l8.291,8.284,17.51-17.5a1.313,1.313,0,0,1,1.857,1.857Z"
        transform="translate(-9 -9)"
      />
    </svg>
  )
}

export default AlertSuccessIcon
