import {all, takeLatest} from 'redux-saga/effects'
import loggedInUserSagaWorker from './saga'
import {actionType} from '../actions/actionTypes'

function* rootSaga() {
  yield all([
    yield takeLatest(
      actionType.UserActionType
        .SET_LOGGED_IN_USER_SAGA_WATCHERS,
      loggedInUserSagaWorker
    ),
  ])
}

export default rootSaga
