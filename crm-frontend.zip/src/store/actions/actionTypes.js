import * as UserActionType from './userActionTypes'
import * as AlertActionType from './AlertActionType'
// eslint-disable-next-line import/prefer-default-export
export const actionType = {
  UserActionType,
  AlertActionType,
}
