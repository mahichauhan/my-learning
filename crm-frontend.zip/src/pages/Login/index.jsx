import React from 'react'
import {FormattedMessage} from 'react-intl'
const Login = () => (
  <>
    <h1>
      <FormattedMessage id="login.title" />
    </h1>
  </>
)

export default Login
