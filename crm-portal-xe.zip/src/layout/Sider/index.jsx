import React from 'react'
import {Menu} from 'antd'
import Navigation from '../../config/navigation'
import {AppMenu, AppSider, LinkStyled} from './styles'
import AppLogo from '../../components/Logo/AppLogo'

const Sider = () => (
  <AppSider collapsedWidth="0">
    <AppLogo />
    <AppMenu defaultSelectedKeys={['1']}>
      {Navigation &&
        Navigation.HR &&
        Navigation.HR.map((navigationItem) => (
          <Menu.Item
            key={navigationItem.id}
            // eslint-disable-next-line prettier/prettier
            icon={navigationItem.icon}>
            <LinkStyled exact to={navigationItem.to}>
              {navigationItem.title}
            </LinkStyled>
          </Menu.Item>
        ))}
    </AppMenu>
  </AppSider>
)

export default Sider
