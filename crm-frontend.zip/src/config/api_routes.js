const API_ROUTES = {
  CAMPUSES: {
    ROOT: '/campuses',
  },
  JOBS: {
    ROOT: '/jobs',
  },
}

export default API_ROUTES
