import React from 'react'
import {Menu} from 'antd'
import {NavLink} from 'react-router-dom'
import Navigation from '../../config/navigation'
import {AppMenu, AppSider} from './styles'
import AppLogo from '../../components/Logo/AppLogo'
import theme from '../../config/theme'
import constants from '../../config/constants'

const Sider = () => {
  return (
    <AppSider collapsedWidth="0">
      <AppLogo />
      <AppMenu
        defaultSelectedKeys={[window.location.pathname]}>
        {Navigation &&
          Navigation.HR &&
          Navigation.HR.map((navigationItem) => {
            return (
              navigationItem.type ===
                constants.NAVIGATION_TYPE.SIDER && (
                <Menu.Item
                  key={navigationItem.to}
                  // eslint-disable-next-line prettier/prettier
                icon={navigationItem.icon}>
                  <NavLink
                    exact
                    to={navigationItem.to}
                    activeClassName="selected-menu"
                    style={{
                      color: theme.white,
                    }}
                    activeStyle={{
                      color: theme.primaryColor,
                    }}>
                    {navigationItem.title}
                  </NavLink>
                </Menu.Item>
              )
            )
          })}
      </AppMenu>
    </AppSider>
  )
}

export default Sider
