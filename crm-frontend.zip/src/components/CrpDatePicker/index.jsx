import React from 'react'
import PropTypes from 'prop-types'
import DatePickerStyled from './styled'
import theme from '../../config/theme'

const CrpDatePicker = (props) => {
  return (
    <DatePickerStyled
      {...props}
      popupStyle={{width: 'auto'}}
    />
  )
}

CrpDatePicker.propTypes = {
  props: PropTypes.any,
}

export default CrpDatePicker
