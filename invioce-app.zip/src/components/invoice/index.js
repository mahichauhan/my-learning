import React from "react";
import PropTypes from "prop-types";

import "./invoice.css";

Invoice.propTypes = {};

const goods = [
  {
    item: "Split AC Installation Charges",
    hsc_sac: "9987",
    Qty: "01",
    price: 1500,
    gstRate: "18%",
    gstAmount: "135",
    cgstAmount: "135",
    amount: 1770,
  },
  {
    item: "Copper Pipe with Insulation",
    hsc_sac: "7411",
    Qty: "3 mtr.",
    price: 2850,
    gstRate: "18%",
    gstAmount: "256.5",
    cgstAmount: "256.5",
    amount: 3363,
  },
  {
    item: "2.5mm Square 3 Core Cable",
    hsc_sac: "9987",
    Qty: "7 mtr.",
    price: 90,
    gstRate: "18%",
    gstAmount: "56.7",
    cgstAmount: "56.7",
    amount: 743.4,
  },
  {
    item: "Wall Stand",
    hsc_sac: "7501",
    Qty: "1",
    price: 550,
    gstRate: "18%",
    gstAmount: "49.5",
    cgstAmount: "49.5",
    amount: 649,
  },
//   {
//     item: "Battery for motorola GP328/GP338 	",
//     hsc_sac: "850500",
//     Qty: "01",
//     price: 6550,
//     gstRate: "28%",
//     gstAmount: "518",
//     amount: 1850,
//   }
];

function Invoice(props) {
  return (
    <div className="container">
        <div className="row">
      <div className="col-md-12">
        <div className="invoice">
          {/* <!-- begin invoice-company --> */}
        <div className="row gstNo">
            <div className="col-md-6">
                <span>GST No : 09GHTPK7534K1ZE</span>
            </div>
            <div className="col-md-6">
                <span className="textRight">Date : 19-04-2022</span>
            </div>
        </div>
          <div className="text-invoice-top invoice-center">
              <span>Tax Invoice</span>
            </div>
          <div className="invoice-company text-inverse f-w-600 invoice-center">
           <h2 className="title">Arth Enterprises</h2>
          </div>
          <p className=""></p>
          <address className="c-address">
            All Kinds of air conditioner Refrigeration <br />
            Electricals Telephone Motor Pump, house warring Etc.
            <br />
            197-C, 2nd floor, Block-50, EWS Sector-73 Noida, Gautam Buddha
            Nagar, Uttar Pradesh-201301
            <br></br>
            <strong>Tel: 9971140872</strong>
          </address>
          {/* <!-- end invoice-company -->
         <!-- begin invoice-header --> */}
          <div className="row invoice-header m-0">
            <div class="col company-from-to">
              <div className="invoice-from">
                <strong>Party Details :</strong>
                <address className="m-t-5 m-b-5">
                  <strong className="text-inverse">Indian Oil coroporation Ldt.</strong>
                  <br />
                  Pipline Devision 
                  <br />
                  A-1 Udyog marg Sector-01 Noida 
                  <br />
                  Pin - 201301
                
                </address>
              </div>
            </div>
            <div class="col">
              <div className="invoice-to">
               
                <address className="m-t-5 m-b-5">
                  {/* <strong className="text-inverse">Company Name</strong> */}
                  <br />
                  Invoice No : 03
                  <br/>
                  Order No : 
                </address>
              </div>
            </div>
          </div>

          {/* <!-- end invoice-header -->
         <!-- begin invoice-content --> */}
          <div className="invoice-content">
            {/* <!-- begin table-responsive --> */}
            <div className="table-responsive">
              <table className="table table-invoice">
                <thead>
                  <tr>
                    <th>Description of Goods</th>
                    <th className="text-center" width="10%">
                      HSN/SAC Code
                    </th>
                    <th className="text-center" width="10%">
                      Qty.
                    </th>
                    <th className="text-center" width="10%">
                      Price
                    </th>
                    <th className="text-right" width="10%">
                      GST Rate
                    </th>
                    <th className="text-right" width="10%">
                      CGST Amt.
                    </th>
                    <th className="text-right" width="10%">
                      SGST Amt.
                    </th>
                    <th className="text-right" width="10%">
                     Total Amount
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {goods.map((product) => (
                    <tr>
                      <td>
                        <span className="text-inverse">
                          {product.item}
                        </span>
                      </td>
                      <td className="text-center">{product.hsc_sac}</td>
                      <td className="text-center">{product.Qty}</td>
                      <td className="text-right">{product.price}</td>
                      <td className="text-right">{product.gstRate}</td>
                      <td className="text-right">{product.gstAmount}</td>
                      <td className="text-right">{product.cgstAmount}</td>                
                      <td className="text-right">{product.amount}</td>
                    </tr>
                  ))}
                  <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td >&nbsp;</td>
                      <td >&nbsp;</td>
                  </tr>
                  <tr><td colspan="7">Total Amount</td><td > 6525.40</td></tr>
                </tbody>
              </table>
            </div>
           
          </div>
          {/* <!-- end invoice-content -->
         <!-- begin invoice-note --> */}
         <div className="invoiceBankDtl">
            <table>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <th>Payment Details :</th>
                                <td>
                                    <span><samp>Bank : </samp>INDIAN OVERSEAS BANK </span>
                                    <span><samp>A/C : </samp>171902000000477 </span>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td>
                    <table>
                            <tr>
                                <th>&nbsp;</th>
                                <td>
                                    <span><samp>Branch : </samp>Sector 58 Noida - 201301</span>
                                    <span><samp>IFSC Code : </samp>IOBA0001719 </span>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
         </div>
          <div className="invoice-note">
            * Make all cheques payable to [Your Company Name]
            <br />
            * Payment is due within 30 days
            <br />* If you have any questions concerning this invoice, contact
            [Name, Phone Number, Email]
          </div>
          {/* <!-- end invoice-note -->
         <!-- begin invoice-footer --> */}
          <div className="invoice-footer">
            <p className="text-center m-b-5 f-w-600">
              THANK YOU FOR YOUR BUSINESS
            </p>
            <p className="text-center">
              <span className="m-r-10">
               
              </span>
              <span className="m-r-10">
                <i className="fa fa-fw fa-lg fa-phone-volume"></i>{" "}
                Tel:9971140872
              </span>
              <span className="m-r-10">
                <i className="fa fa-fw fa-lg fa-envelope"></i> ae.tiwari@yahoo.com
              </span>
            </p>
          </div>
          {/* <!-- end invoice-footer --> */}
        </div>
      </div>
      </div>
    </div>
  );
}

export default Invoice;
