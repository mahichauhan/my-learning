import {put} from 'redux-saga/effects'
import {actionType} from '../actions/actionTypes'

export default function* loggedInUserSagaWorker({payload}) {
  yield put({
    type: actionType.UserActionType
      .SET_LOGGED_IN_USER_REDUCER,
    payload,
  })
}
