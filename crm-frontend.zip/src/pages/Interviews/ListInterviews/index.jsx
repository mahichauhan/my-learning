import React from 'react'
import {Button, Col} from 'antd'
import CrpSearchBar from '../../../components/CrpSearchBar'
import {CrpTable, CrpCard} from '../../../components'
import {SearchContainer, StyledRow} from './styles'
import {StyledUl} from '../../Candidates/ListCandidates/styles'
import listCandidates from '../../../assets/dummy-data/candidates/listCandidates.json'
import listCandidatesColumnMeta from '../../Candidates/ListCandidates/columnMeta'

const ListInterviews = () => {
  return (
    <>
      <StyledRow>
        <SearchContainer span={10}>
          <CrpSearchBar
            placeholder="Search Interview"
            buttonType="primary"
          />
        </SearchContainer>
      </StyledRow>
      <StyledRow>
        <Col span={24}>
          <CrpCard width="auto">
            <CrpTable
              dataSource={listCandidates}
              title="Interviews to be scheduled"
              columns={listCandidatesColumnMeta}
              pageSize={10}
              actionList={
                <StyledUl>
                  <li>
                    <Button type="link">
                      Edit Details
                    </Button>
                  </li>
                  <li>
                    <Button type="link">Delete</Button>
                  </li>
                </StyledUl>
              }
            />
          </CrpCard>
        </Col>
      </StyledRow>
    </>
  )
}

export default ListInterviews
