import React from 'react'
import PropTypes from 'prop-types'
import InputStyled from './styled'

function CrpInputField({placeholder}) {
  return <InputStyled placeholder={placeholder} />
}

CrpInputField.propTypes = {
  placeholder: PropTypes.string,
}

CrpInputField.defaultProps = {
  placeholder: '',
}

export default CrpInputField
