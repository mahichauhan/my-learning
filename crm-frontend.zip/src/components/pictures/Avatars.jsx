import React from 'react'
import {Avatar, Image} from 'antd'
import PropTypes from 'prop-types'

const Avatars = (props) => {
  // eslint-disable-next-line react/prop-types
  const {useravatar} = props

  return (
    <>
      <Avatar
        {...props}
        // eslint-disable-next-line react/prop-types
        shape={useravatar.shape}
        // eslint-disable-next-line react/prop-types
        size={useravatar.size}
        // eslint-disable-next-line react/prop-types
        src={
          <Image
            src={`${useravatar.path}`}
            preview={false}
          />
        }
      />
    </>
  )
}

Avatar.defaultProps = {
  useravatar: PropTypes.shape({
    shape: 'square',
    size: 'big',
    path: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
  }),
}

Avatars.prototype = {
  useravatar: PropTypes.shape({
    shape: PropTypes.string,
    size: PropTypes.string,
    path: PropTypes.string,
  }),
}

export default Avatars
