import React from 'react'

const JobBoard = () => {
  return <></>
}

export default JobBoard
