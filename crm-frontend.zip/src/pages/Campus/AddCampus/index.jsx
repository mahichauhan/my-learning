import React from 'react'
import {useHistory} from 'react-router-dom'
import {Col, Form, Typography, Spin} from 'antd'
import {Formik} from 'formik'
import * as Yup from 'yup'
import {useDispatch} from 'react-redux'
import {
  SaveOutlined,
  CloseCircleOutlined,
} from '@ant-design/icons'
import theme from '../../../config/theme'
import {
  IconButton,
  CrpCard,
  CrpInputField,
} from '../../../components'

import StyledRow from './styled'
import CampusService from '../../../services/CampusService'
import {setAlert} from '../../../store/actions'
import {AlertConfig} from '../../../components/HOC/AlertProvider/AlertConfig'
import APP_ROUTES from '../../../config/app.routes'

const {Title} = Typography

const AddCampus = () => {
  const dispatch = useDispatch()
  const history = useHistory()

  return (
    <Formik
      initialValues={{
        name: '',
        city: '',
        state: '',
        contactName: '',
        contactDesignation: '',
        contactEmail: '',
        contactNumber: '',
      }}
      validationSchema={Yup.object().shape({
        name: Yup.string()
          .min(2, 'Too Short!')
          .required('Campus name is required'),
        city: Yup.string()
          .min(2, 'Too Short!')
          .required('City name is required!'),
        state: Yup.string()
          .min(2, 'Too Short!')
          .required('City name is required!'),
        contactName: Yup.string()
          .min(2, 'Too Short!')
          .required('City name is required!'),
        contactDesignation: Yup.string()
          .min(2, 'Too Short!')
          .required(
            'Campus contact designation is required!'
          ),
        contactEmail: Yup.string()
          .min(2, 'Too Short!')
          .email('Email is invalid!')
          .required('Contact details is required!'),
        contactNumber: Yup.string()
          .matches(/^$|[0-9]{10}/)
          .required('Campus contact phone no is required!'),
      })}
      onSubmit={(values, actions) => {
        ;(async () => {
          let notification = {
            title: `You successfully added a new Campus`,
            description:
              'This new campus added will not be available for Reports and Tracking',
            key: 'newCampusCreated',
            status: AlertConfig.ALERT_SUCCESS,
          }
          try {
            await CampusService.createCampus(values)
            setTimeout(() => {
              window.location.href =
                APP_ROUTES.HR_MODULE.ROOT +
                APP_ROUTES.HR_MODULE.DASHBOARD
            }, 3000)
          } catch (error) {
            notification = {
              title: `Failure while creating a Campus`,
              description: error?.message,
              key: 'newCampusCreationFailure',
              status: AlertConfig.ALERT_ERROR,
            }
          }
          actions.setSubmitting(false)
          dispatch(setAlert({notification}))
        })()
      }}>
      {({
        errors,
        handleChange,
        handleSubmit,
        touched,
        values,
        isSubmitting,
      }) => (
        <Spin spinning={isSubmitting}>
          <Form colon={false} onFinish={handleSubmit}>
            <StyledRow justify="start" gutter={[20, 32]}>
              <Col span={12}>
                <CrpCard width="auto">
                  <Title level={5} type="secondary">
                    Basic Campus Details
                  </Title>
                  <Form.Item
                    name="name"
                    label="Campus Name"
                    type="secondary"
                    hasFeedback={Boolean(
                      touched.name && errors.name
                    )}
                    validateStatus={
                      touched.name && errors.name
                        ? 'error'
                        : ''
                    }
                    help={touched.name && errors.name}>
                    <CrpInputField
                      placeholder="Campus Name"
                      type="text"
                      onChange={handleChange}
                      name="name"
                      valuePropName={values.name}
                    />
                  </Form.Item>
                  <Form.Item
                    label="Campus City"
                    hasFeedback={Boolean(
                      touched.city && errors.city
                    )}
                    validateStatus={
                      touched.city && errors.city
                        ? 'error'
                        : ''
                    }
                    help={touched.city && errors.city}>
                    <CrpInputField
                      placeholder="Campus City"
                      onChange={handleChange}
                      name="city"
                      valuePropName={values.city}
                    />
                  </Form.Item>
                  <Form.Item
                    label="Campus State"
                    hasFeedback={Boolean(
                      touched.state && errors.state
                    )}
                    validateStatus={
                      touched.state && errors.state
                        ? 'error'
                        : ''
                    }
                    help={touched.state && errors.state}>
                    <CrpInputField
                      placeholder="Campus State"
                      onChange={handleChange}
                      name="state"
                      valuePropName={values.state}
                    />
                  </Form.Item>
                  <Form.Item
                    label="Campus Contact Name"
                    hasFeedback={Boolean(
                      touched.contactName &&
                        errors.contactName
                    )}
                    validateStatus={
                      touched.contactName &&
                      errors.contactName
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.contactName &&
                      errors.contactName
                    }>
                    <CrpInputField
                      placeholder="Campus Contact Name"
                      onChange={handleChange}
                      name="contactName"
                      valuePropName={values.contactName}
                    />
                  </Form.Item>
                  <Form.Item
                    label="Campus Contact Designation"
                    hasFeedback={Boolean(
                      touched.contactDesignation &&
                        errors.contactDesignation
                    )}
                    validateStatus={
                      touched.contactDesignation &&
                      errors.contactDesignation
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.contactDesignation &&
                      errors.contactDesignation
                    }>
                    <CrpInputField
                      placeholder="Campus Contact Designation"
                      onChange={handleChange}
                      name="contactDesignation"
                      valuePropName={
                        values.contactDesignation
                      }
                    />
                  </Form.Item>
                </CrpCard>
              </Col>
              <Col span={12}>
                <CrpCard width="auto">
                  <Title level={5} type="secondary">
                    Contact Details
                  </Title>
                  <Form.Item
                    label="Campus Contact Email"
                    hasFeedback={Boolean(
                      touched.contactEmail &&
                        errors.contactEmail
                    )}
                    validateStatus={
                      touched.contactEmail &&
                      errors.contactEmail
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.contactEmail &&
                      errors.contactEmail
                    }>
                    <CrpInputField
                      placeholder="Campus Contact Email"
                      onChange={handleChange}
                      name="contactEmail"
                      valuePropName={values.contactEmail}
                    />
                  </Form.Item>
                  <Form.Item
                    label="Campus Contact Phone No"
                    hasFeedback={Boolean(
                      touched.contactNumber &&
                        errors.contactNumber
                    )}
                    validateStatus={
                      touched.contactNumber &&
                      errors.contactNumber
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.contactNumber &&
                      errors.contactNumber
                    }>
                    <CrpInputField
                      placeholder="Campus Contact Phone No"
                      onChange={handleChange}
                      name="contactNumber"
                      valuePropName={values.contactNumber}
                    />
                  </Form.Item>
                </CrpCard>
              </Col>
              <Col span={12}>
                <CrpCard
                  width="auto"
                  borderRadius={4}
                  height={100}>
                  <div className="buttondiv">
                    <IconButton
                      incons={CloseCircleOutlined}
                      color={theme.black}
                      onClick={() => history.goBack()}>
                      cancel
                    </IconButton>

                    <IconButton
                      incons={SaveOutlined}
                      htmlType="submit"
                      disabled={isSubmitting}>
                      save
                    </IconButton>
                  </div>
                </CrpCard>
              </Col>
            </StyledRow>
          </Form>
        </Spin>
      )}
    </Formik>
  )
}

export default AddCampus
