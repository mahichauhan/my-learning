import React from 'react'
import {Button, Popover, Typography} from 'antd'
import theme from '../../../config/theme'

const listCandidatesColumnMeta = [
  {
    title: 'Candidate Name',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'CGPA',
    dataIndex: 'cgpa',
    key: 'cgpa',
    render: () => '7.7',
  },
  {
    title: 'Course/Specialisation',
    dataIndex: 'courseSpecialization',
    key: 'courseSpecialization',
    render: () => 'B.Tech Computer Science',
  },
  {
    title: 'Position Applied',
    dataIndex: 'positionApplied',
    key: 'positionApplied',
    render: () => 'Python Developer',
  },
  {
    title: 'Interview Round',
    dataIndex: 'interviewRound',
    key: 'interviewRound',
    render: () => 'L1 Interview',
  },
  {
    title: 'Next Interview Date',
    dataIndex: 'nextInterview',
    key: 'nextInterview',
    render: () => 'Not Scheduled',
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    render: (text, _record, _index) => {
      let textColor = theme.primaryColor

      if (['L1 CLEARED', 'L1 SCHEDULED'].includes(text)) {
        textColor = theme.greenYellow
      } else if (
        ['L2 CLEARED', 'L2 SCHEDULED'].includes(text)
      ) {
        textColor = theme.orange
      } else if (['OFFERED'].includes(text)) {
        textColor = theme.green
      } else if (['APPLIED'].includes(text)) {
        textColor = theme.pink
      }
      return (
        <Typography.Text style={{color: textColor}}>
          {text || 'APPLIED'}
        </Typography.Text>
      )
    },
  },
]

export default listCandidatesColumnMeta
