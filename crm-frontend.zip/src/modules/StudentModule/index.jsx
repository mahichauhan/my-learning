import React from 'react'
import {BrowserRouter as Router} from 'react-router-dom'
import StudentDashboard from '../../pages/Dashboard/StudentDashboard'
import APP_ROUTES from '../../config/app.routes'
import PrivateRoute from '../../routes/PrivateRoute'

const {STUDENT_MODULE} = APP_ROUTES

const StudentModule = () => (
  <Router basename={STUDENT_MODULE.ROOT}>
    <PrivateRoute
      exact
      path={STUDENT_MODULE.DASHBOARD}
      component={StudentDashboard}
    />
  </Router>
)

export default StudentModule
