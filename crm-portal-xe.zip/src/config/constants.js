// eslint-disable-next-line import/prefer-default-export
export const APP_RUNNING_ON = 'DEVELOPMENT'
