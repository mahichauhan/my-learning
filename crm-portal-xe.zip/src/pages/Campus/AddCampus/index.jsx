import React from 'react'
import {Row, Col, Form, Typography} from 'antd'

import {
  SaveOutlined,
  CloseCircleOutlined,
} from '@ant-design/icons'
import styled from 'styled-components'
import theme from '../../../config/theme'
import {
  IconButton,
  CrpCard,
  CrpInputField,
} from '../../../components'

// import theme from '../../../config/Theme'

const StyledRow = styled(Row)`
  width: 90%;
  & .buttondiv {
    display: flex;
    justify-content: flex-end;
    margin: -1rem !important;
  }
  & .xebiacrp-form-item {
    display: block !important;
  }
  & .xebiacrp-card-body {
    padding: 2rem;
    & .xebiacrp-col.xebiacrp-form-item-label : {
      margin-left: 8px !important;
    }
  }
  & .xebiacrp-form-item-label > label {
    display: contents;
    font-weight: 600;
  }
`

const {Title} = Typography

const AddCampus = () => {
  const [formvalue] = Form.useForm()

  console.log(formvalue)

  return (
    <Form colon={false}>
      <StyledRow justify="start" gutter={[20, 32]}>
        <Col span={12}>
          <CrpCard width="auto">
            <Title level={5} type="secondary">
              Basic Campus Details
            </Title>
            <Form.Item label="Campus Name" type="secondary">
              <CrpInputField
                placeholder="Campus Name"
                name="Campus Name"
                type="text"
              />
            </Form.Item>
            <Form.Item label="Campus City">
              <CrpInputField placeholder="Campus City" />
            </Form.Item>
            <Form.Item label="Campus State">
              <CrpInputField placeholder="Campus State" />
            </Form.Item>
            <Form.Item label="Campus Contact Name">
              <CrpInputField placeholder="Campus Contact Name" />
            </Form.Item>
            <Form.Item label="Campus Contact Designation">
              <CrpInputField placeholder="Campus Contact Designation" />
            </Form.Item>
          </CrpCard>
        </Col>
        <Col span={12}>
          <CrpCard width="auto">
            <Title level={5} type="secondary">
              Contact Details
            </Title>
            <Form.Item label="Contact details">
              <CrpInputField placeholder="Contact details" />
            </Form.Item>
            <Form.Item label="Campus Contact Phone No">
              <CrpInputField placeholder="Campus Contact Phone No" />
            </Form.Item>
          </CrpCard>
        </Col>
        <Col span={12}>
          <CrpCard
            width="auto"
            borderRadius={4}
            height={100}>
            <div className="buttondiv">
              <IconButton
                incons={CloseCircleOutlined}
                color={theme.black}>
                cancel
              </IconButton>

              <IconButton incons={SaveOutlined}>
                save
              </IconButton>
            </div>
          </CrpCard>
        </Col>
      </StyledRow>
    </Form>
  )
}

export default AddCampus
