import React from 'react'
import {Row, Col, Image} from 'antd'
import {StyledRow} from './styled'
import {CrpCard} from '../../../../components'
import HrProfileData from '../../../../assets/dummy-data/hrprofile/hrprofiledata.json'
import {FormattedMessage} from 'react-intl'

const HrProfile = (props) => {
  return (
    <StyledRow>
      <Col span={12}>
        <CrpCard width="auto" borderRadius={4}>
          <StyledRow paddingLeft="2rem" marginBottom="2rem">
            <Col span={23}>
              <h2> USER INFORMATION </h2>
            </Col>
          </StyledRow>
          <StyledRow paddingLeft="2rem">
            <Col span={12}>
              {Object.keys(HrProfileData).map(
                (hrProfileKey) => {
                  return (
                    !['profilePicture'].includes(
                      hrProfileKey
                    ) && (
                      <Row key={hrProfileKey}>
                        <Col span={12}>
                          <h3>
                            <FormattedMessage
                              id={`userProfile.${hrProfileKey}`}
                            />
                          </h3>
                        </Col>
                        <Col span={12}>
                          {HrProfileData[hrProfileKey]}
                        </Col>
                      </Row>
                    )
                  )
                }
              )}
            </Col>
            <Col span={12}>
              <StyledRow>
                <Col span={6} />
                <Col span={18}>
                  <Image
                    width={200}
                    className="profile-picture"
                    src={HrProfileData.profilePicture}
                    preview={false}
                  />
                </Col>
              </StyledRow>
            </Col>
          </StyledRow>
        </CrpCard>
      </Col>
    </StyledRow>
  )
}

export default HrProfile
