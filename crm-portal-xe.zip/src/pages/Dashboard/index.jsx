import React from 'react'
import AppLayout from '../../layout'

const Dashboard = () => (
  <AppLayout>This is Content</AppLayout>
)

export default Dashboard
