import React from 'react'
import HrDashboard from '../../pages/Dashboard/HrDashboard'
import AddCampus from '../../pages/Campus/AddCampus'
import AddOpenJobs from '../../pages/Jobs/AddOpenJobs'
import Reports from '../../pages/Reports/intex'
import APP_ROUTES from '../../config/app.routes'
import AppLayout from '../../layout'
import PrivateRoute from '../../routes/PrivateRoute'
import ListCandidates from '../../pages/Candidates/ListCandidates'
import JobBoard from '../../pages/Jobs/JobBoard'
import ListInterviews from '../../pages/Interviews/ListInterviews'
import HrSettings from '../../pages/Users/Settings'
import HrProfile from '../../pages/Users/Profiles/HrProfile'

const {HR_MODULE} = APP_ROUTES

const HrModule = () => (
  <AppLayout>
    <>
      <PrivateRoute
        exact
        path={HR_MODULE.ROOT + HR_MODULE.DASHBOARD}
        component={HrDashboard}
      />
      <PrivateRoute
        exact
        path={
          HR_MODULE.ROOT +
          HR_MODULE.CAMPUSES.ROOT +
          HR_MODULE.CAMPUSES.ADD
        }
        component={AddCampus}
      />
      <PrivateRoute
        exact
        path={HR_MODULE.ROOT + HR_MODULE.CANDIDATES.ROOT}
        component={ListCandidates}
      />
      <PrivateRoute
        exact
        path={
          HR_MODULE.ROOT +
          HR_MODULE.JOBS.ROOT +
          HR_MODULE.JOBS.BOARD
        }
        component={JobBoard}
      />
      <PrivateRoute
        exact
        path={HR_MODULE.ROOT + HR_MODULE.INTERVIEWS.ROOT}
        component={ListInterviews}
      />
      <PrivateRoute
        exact
        path={
          HR_MODULE.ROOT +
          HR_MODULE.JOBS.ROOT +
          HR_MODULE.JOBS.ADD
        }
        component={AddOpenJobs}
      />
      <PrivateRoute
        exact
        path={HR_MODULE.ROOT + HR_MODULE.REPORTS}
        component={Reports}
      />
      <PrivateRoute
        exact
        path={HR_MODULE.ROOT + HR_MODULE.USERS.SETTINGS}
        component={HrSettings}
      />
      <PrivateRoute
        exact
        path={HR_MODULE.ROOT + HR_MODULE.USERS.PROFILE}
        component={HrProfile}
      />
    </>
  </AppLayout>
)

export default HrModule
