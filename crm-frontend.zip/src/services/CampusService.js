import API_ROUTES from '../config/api_routes'
import crpAxios from '../config/axios'

class CampusService {
  static createCampus = (campus) => {
    return crpAxios.post(API_ROUTES.CAMPUSES.ROOT, campus)
  }
}

export default CampusService
