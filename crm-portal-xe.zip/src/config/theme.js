const theme = {
  boxshadowColor: '#384AC236',
  spacing: (value) => value * 8,
  primaryColor: '#19237E',
  contentBg: '#f6f6f9 0% 0% no-repeat padding-box',
  menuPadding: '1.5rem',
  menuBg: '#f6f6f9 0% 0% no-repeat padding-box',
  menuMinHeight: 'minheight',
  backGroundColor: '#f6f6f9',
  menuColor: 'var(--unnamed-color-ffffff)',
  margine: '1.5rem 1rem 0',
  minheight: '780px',
  hoverBtnBackground: '#7675d129',
  btnColor: '#0613c1',
  btnHoverColor: '#0613c1',
  black: '#353536',
  placeholderColor: 'rgba(53, 53, 54, 1)',
  inputBottomBorder: 'rgba(56, 74, 194, 0.6)',
  fontWeight: 500,
  inputColor: 'rgba(237, 237, 237, 1)',
}

export default theme
