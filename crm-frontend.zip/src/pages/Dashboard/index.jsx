import React from 'react'
import AppLayout from '../../layout'

const Dashboard = () => {
  return (
    <AppLayout>
      <>Dashboard</>
    </AppLayout>
  )
}

export default Dashboard
