import React from 'react'
import {Col, Form, Typography, Select, Spin} from 'antd'
import {useHistory} from 'react-router-dom'
import {useDispatch} from 'react-redux'
import {Formik} from 'formik'
import * as Yup from 'yup'
import {
  SaveOutlined,
  CloseCircleOutlined,
} from '@ant-design/icons'
import theme from '../../../config/theme'
import {
  IconButton,
  CrpCard,
  CrpInputField,
  CrpTextAreaField,
  CrpSelectField,
  CrpDatePicker,
} from '../../../components'

import JobsService from '../../../services/JobsService'
import {setAlert} from '../../../store/actions'
import {AlertConfig} from '../../../components/HOC/AlertProvider/AlertConfig'
import moment from 'moment'

import StyledRow from './styled'

const {Option} = Select

const {Title} = Typography

const AddOpenJobs = () => {
  const dispatch = useDispatch()
  const history = useHistory()
  const [form] = Form.useForm()

  return (
    <Formik
      initialValues={{
        jobTitle: '',
        noOfOpenPositions: '',
        location: '',
        jobType: '',
        JobDescription: '',
        Responsibilities: '',
        requiements: '',
        hireByDate: '',
      }}
      validationSchema={Yup.object().shape({
        jobTitle: Yup.string()
          .min(2, 'Too Short!')
          .required('Job title is required'),
        noOfOpenPositions: Yup.number()
          .min(2, 'Too Short!')
          .required('No of open positions is required!'),
        location: Yup.string().required(
          'Location is required!'
        ),
        jobType: Yup.string().required(
          'Job type is required!'
        ),
        JobDescription: Yup.string().required(
          'Job description is required!'
        ),
        Responsibilities: Yup.string().required(
          'Job Responsibilities are required!'
        ),
        requiements: Yup.string().required(
          'Job requiements are required!'
        ),
      })}
      onSubmit={async (
        values,
        {setSubmitting, resetForm}
      ) => {
        let notification = {
          title: `You successfully added a new Job`,
          description:
            'This new job added will not be available for now',
          key: 'newJobCreated',
          status: AlertConfig.ALERT_SUCCESS,
        }
        try {
          setSubmitting(true)
          const {
            jobTitle,
            noOfOpenPositions,
            location,
            jobType,
            JobDescription,
            Responsibilities,
            requiements,
            hireByDate,
          } = values

          const reqToSend = {
            title: jobTitle,
            openPositions: noOfOpenPositions,
            hireByDate, // '2012-04-23T18:25:43.511Z',
            location: location,
            type: jobType,
            description: JobDescription,
            responsibility: Responsibilities,
            requirement: requiements,
          }
          await JobsService.createJob(reqToSend)
          form.resetFields()
          setSubmitting(false)
          resetForm(null)
        } catch (error) {
          setSubmitting(false)
          notification = {
            title: `Failure while creating a Campus`,
            description: error?.message,
            key: 'newJobCreatedFailure',
            status: AlertConfig.ALERT_ERROR,
          }
        }
        dispatch(setAlert({notification}))
      }}>
      {({
        errors,
        handleChange,
        handleSubmit,
        isSubmitting,
        touched,
        values,
        setFieldValue,
      }) => (
        <Spin size="large" spinning={isSubmitting}>
          <Form
            colon={false}
            onFinish={handleSubmit}
            form={form}>
            <StyledRow justify="start" gutter={[20, 32]}>
              <Col span={12}>
                <CrpCard width="auto">
                  <Title level={5} type="secondary">
                    Add Job Details
                  </Title>
                  <Form.Item
                    name="jobTitle"
                    label="Job Title"
                    type="secondary"
                    hasFeedback={Boolean(
                      touched.jobTitle && errors.jobTitle
                    )}
                    validateStatus={
                      touched.jobTitle && errors.jobTitle
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.jobTitle && errors.jobTitle
                    }>
                    <CrpInputField
                      placeholder="Job Title"
                      type="text"
                      onChange={handleChange}
                      name="jobTitle"
                      valuePropName={values.jobTitle}
                    />
                  </Form.Item>
                  <Form.Item
                    label="No. Of Open Positions"
                    hasFeedback={Boolean(
                      touched.noOfOpenPositions &&
                        errors.noOfOpenPositions
                    )}
                    validateStatus={
                      touched.noOfOpenPositions &&
                      errors.noOfOpenPositions
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.noOfOpenPositions &&
                      errors.noOfOpenPositions
                    }>
                    <CrpInputField
                      type="number"
                      placeholder="No. Of Open Positions"
                      onChange={handleChange}
                      name="noOfOpenPositions"
                      value={values.noOfOpenPositions}
                    />
                  </Form.Item>
                  <Form.Item
                    name="hireByDate"
                    label="Hire By Date"
                    hasFeedback={Boolean(
                      touched.hireByDate &&
                        errors.hireByDate
                    )}
                    validateStatus={
                      touched.hireByDate &&
                      errors.hireByDate
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.hireByDate &&
                      errors.hireByDate
                    }>
                    <CrpDatePicker
                      name="hireByDate"
                      onChange={(date) =>
                        setFieldValue(
                          'hireByDate',
                          moment(date).format()
                        )
                      }
                      format="YYYY-MM-DD"
                    />
                  </Form.Item>
                  <Form.Item
                    label="Location"
                    hasFeedback={Boolean(
                      touched.location && errors.location
                    )}
                    validateStatus={
                      touched.location && errors.location
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.location && errors.location
                    }>
                    <CrpSelectField
                      placeholder="Location"
                      onChange={(e) =>
                        setFieldValue('location', e)
                      }
                      name="location"
                      bordered={false}
                      value={values.location}>
                      <Option value="Noida">Noida</Option>
                      <Option value="Pune">Pune</Option>
                      <Option value="Gurugram">
                        Gurugram
                      </Option>
                      <Option value="Bengaluru">
                        Bengaluru
                      </Option>
                      <Option value="Remote">Remote</Option>
                    </CrpSelectField>
                  </Form.Item>
                  <Form.Item
                    label="Job Type"
                    hasFeedback={Boolean(
                      touched.jobType && errors.jobType
                    )}
                    validateStatus={
                      touched.jobType && errors.jobType
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.jobType && errors.jobType
                    }>
                    <CrpSelectField
                      placeholder="Job Type"
                      bordered={false}
                      name="jobType"
                      onChange={(e) =>
                        setFieldValue('jobType', e)
                      }
                      value={values.jobType}>
                      <Option value="Fulltime">
                        Full Time
                      </Option>
                      <Option value="parttime">
                        Part Time
                      </Option>
                      <Option value="Internship">
                        Internship
                      </Option>
                    </CrpSelectField>
                  </Form.Item>
                </CrpCard>
                <div className="actionsection">
                  <CrpCard
                    width="auto"
                    borderRadius={4}
                    height={100}>
                    <div className="buttondiv">
                      <IconButton
                        incons={CloseCircleOutlined}
                        color={theme.black}
                        onClick={() => history.goBack()}>
                        cancel
                      </IconButton>

                      <IconButton
                        incons={SaveOutlined}
                        htmlType="submit"
                        disabled={isSubmitting}>
                        save
                      </IconButton>
                    </div>
                  </CrpCard>
                </div>
              </Col>
              <Col span={12}>
                <CrpCard width="auto">
                  <Title level={5} type="secondary">
                    Add Job Description
                  </Title>
                  <Form.Item
                    label="Job Description"
                    hasFeedback={Boolean(
                      touched.JobDescription &&
                        errors.JobDescription
                    )}
                    validateStatus={
                      touched.JobDescription &&
                      errors.JobDescription
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.JobDescription &&
                      errors.JobDescription
                    }>
                    <CrpTextAreaField
                      autoSize={{
                        minRows: 4.5,
                        maxRows: 6,
                      }}
                      placeholder="Job Description"
                      onChange={handleChange}
                      name="JobDescription"
                      value={values.JobDescription}
                    />
                  </Form.Item>
                  <Form.Item
                    label="Responsibilities"
                    hasFeedback={Boolean(
                      touched.Responsibilities &&
                        errors.Responsibilities
                    )}
                    validateStatus={
                      touched.Responsibilities &&
                      errors.Responsibilities
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.Responsibilities &&
                      errors.Responsibilities
                    }>
                    <CrpTextAreaField
                      autoSize={{
                        minRows: 4.5,
                        maxRows: 6,
                      }}
                      placeholder="Responsibilities"
                      onChange={handleChange}
                      name="Responsibilities"
                      value={values.Responsibilities}
                    />
                  </Form.Item>
                  <Form.Item
                    label="Requiements"
                    hasFeedback={Boolean(
                      touched.requiements &&
                        errors.requiements
                    )}
                    validateStatus={
                      touched.requiements &&
                      errors.requiements
                        ? 'error'
                        : ''
                    }
                    help={
                      touched.requiements &&
                      errors.requiements
                    }>
                    <CrpTextAreaField
                      type="textarea"
                      autoSize={{
                        minRows: 4.5,
                        maxRows: 6,
                      }}
                      placeholder="Requiements"
                      onChange={handleChange}
                      name="requiements"
                      value={values.requiements}
                    />
                  </Form.Item>
                </CrpCard>
              </Col>
            </StyledRow>
          </Form>
        </Spin>
      )}
    </Formik>
  )
}

export default AddOpenJobs
