import {Row, Typography} from 'antd'
import styled from 'styled-components'
import theme from '../../../../config/theme'
const {Title, Paragraph} = Typography

const StyledRow = styled(Row)({
  width: '100%',
  marginBottom: '2rem',
  '& .xebiacrp-form-item': {
    display: 'block !important',
  },
  '& .usersetting': {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    '& .xebiacrp-switch-checked': {
      backgroundColor: theme.arrowColor,
    },
  },
  '& .xebiacrp-card-body': {
    padding: '1rem 1rem 1rem 4rem',
    '& .xebiacrp-col.xebiacrp-form-item-label': {
      marginLeft: '0.5rem !important',
    },
    '& .xebiacrp-typography >span': {
      marginRight: theme.spacing(9),
    },
    '& h5': {
      color: theme.black,
      textTransform: 'uppercase',
    },
  },
  '& .crpavatar': {
    marginRight: theme.spacing(4),
    marginBottom: theme.spacing(4),
  },
  '& .table-header': {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    marginBottom: 10,
    '& .add-member': {
      padding: '0px 5rem',
      fontWeight: theme.fontWeight,
      background: `${theme.arrowColor} 0% 0% no-repeat padding-box`,
      boxShadow: `box-shadow: 0px 3px 6px ${theme.iceberg}`,
      textTransform: 'uppercase',
      border: 'none',
    },
  },
})

export const ParagraphStyled = styled(Paragraph)({
  color: theme.arrowColor,
  letterSpacing: '0.11px',
  opacity: 1,
  fontWeight: 600,
  padding: `0.5rem 0`,
})

export const StyledUl = styled('ul')({
  listStyle: 'none',
  paddingLeft: theme.pxToRem(10),
  marginBottom: theme.pxToRem(3),

  '.xebiacrp-btn': {
    padding: `0 ${theme.pxToRem(10)}`,
    height: theme.pxToRem(10),
    span: {
      fontSize: theme.pxToRem(14),
      color: theme.darkGrey,
    },
  },
})

export default StyledRow
