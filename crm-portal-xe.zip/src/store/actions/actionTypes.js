import * as UserAction from './userActionTypes'

// eslint-disable-next-line import/prefer-default-export
export const actionType = {
  UserAction,
}
