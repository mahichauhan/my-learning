class AuthService {
  static isUserLoggedIn = () => true
}

export default AuthService
