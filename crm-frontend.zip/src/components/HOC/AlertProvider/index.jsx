import React, {useEffect, useState} from 'react'
import {Button, notification} from 'antd'
import {
  shallowEqual,
  useDispatch,
  useSelector,
} from 'react-redux'
import {AlertConfig} from './AlertConfig'
import AlertSuccessIcon from '../../icons/AlertSuccessIcon'
import {removetAlert} from '../../../store/actions'
import {CloseCircleFilled} from '@ant-design/icons'
import theme from '../../../config/theme'

const AlertProvider = () => {
  const dispatch = useDispatch()
  const alert = useSelector(
    (state) => state.ALERT,
    shallowEqual
  )

  useEffect(() => {
    if (Object.keys(alert).length > 0) {
      handleNotification(alert.notification)

      /** Removing alert object from redux store */
      setTimeout(() => {
        dispatch(removetAlert())
      }, 2000)
    }
  }, [alert])

  const handleNotification = (notificationMessage) => {
    const config = {
      message: notificationMessage.title,
      description: notificationMessage.description,
      placement: AlertConfig.ALERT_PLACEMENT,
      duration:
        notificationMessage.duration ||
        AlertConfig.ALERT_DURATION,
      key: notificationMessage.key,
    }
    switch (notificationMessage.status) {
      case AlertConfig.ALERT_SUCCESS:
        notification.success({
          ...config,
          icon: <AlertSuccessIcon />,
        })
        break
      case AlertConfig.ALERT_INFO:
        notification.info(config)
        break
      case AlertConfig.ALERT_WARNING:
        notification.warning(config)
        break
      case AlertConfig.ALERT_WARN:
        notification.warn(config)
        break
      case AlertConfig.ALERT_WARN:
        notification.open(config)
        break
      case AlertConfig.ALERT_OPEN:
        notification.close(config)
        break
      case AlertConfig.ALERT_CLOSE:
        notification.destroy(config)
        break
      case AlertConfig.ALERT_DESTROY:
        notification.success(config)
        break
      default:
        notification.error({
          ...config,
          icon: (
            <CloseCircleFilled
              style={{
                color: theme.dangerColor,
                fontSize: theme.pxToRem(40),
                marginTop: theme.pxToRem(5),
              }}
            />
          ),
        })
        break
    }
  }

  return <></>
}

export default AlertProvider
