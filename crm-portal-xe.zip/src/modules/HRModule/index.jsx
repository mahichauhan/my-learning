import React from 'react'
import {
  Route,
  BrowserRouter as Router,
} from 'react-router-dom'
import HrDashboard from '../../pages/Dashboard/Hrdashboard'
import AddCampus from '../../pages/Campus/AddCampus'
import APP_ROUTES from '../../config/app.routes'
import AppLayout from '../../layout'

const {HR_MODULE} = APP_ROUTES

const HrModule = () => (
  <AppLayout>
    <Router basename={HR_MODULE.ROOT}>
      <Route
        exact
        path={HR_MODULE.DASHBOARD}
        component={HrDashboard}
      />
      <Route
        exact
        path={HR_MODULE.ADDCAMPUS}
        component={AddCampus}
      />
    </Router>
  </AppLayout>
)

export default HrModule
