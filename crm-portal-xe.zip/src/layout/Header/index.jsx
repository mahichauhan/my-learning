import React from 'react'
import {Layout, Menu, Row, Col} from 'antd'
import {BellOutlined} from '@ant-design/icons'
import {FormattedMessage} from 'react-intl'
import Avatars from '../../components/pictures/Avatars'
import HeaderMenu from './styles'

const Header = () => {
  const headerAvatarSetting = {
    shape: 'square',
    size: 'big',
    path: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
  }

  return (
    <>
      <Layout.Header className="header">
        <Row>
          {' '}
          <Col span={8}>
            <div className="header-logo">
              <h1>
                <FormattedMessage id="header.title" />
              </h1>
            </div>
             
          </Col>
          <Col span={8} offset={8}>
            <HeaderMenu theme="dark" mode="horizontal">
              <Menu.Item>
                <BellOutlined />
              </Menu.Item>
              <Menu.Item>Hi, Garima Mohan</Menu.Item>
              <Menu.Item>
                <Avatars userAvatar={headerAvatarSetting} />
              </Menu.Item>
            </HeaderMenu>
          </Col>{' '}
        </Row>
      </Layout.Header>
    </>
  )
}

export default Header
