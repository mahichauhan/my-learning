import {Menu} from 'antd'
import styled from 'styled-components'
import theme from '../../../config/theme'

export const StyledUserMenu = styled(Menu)({
  borderRight: 'none',
})

export const StyledUserMenuItem = styled(Menu.Item)({
  color: theme.darkGrey,

  '&:hover': {
    backgroundColor: theme.hoverBtnBackground,
  },
})
