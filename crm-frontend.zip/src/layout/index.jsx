import React from 'react'
import {Layout} from 'antd'
import PropTypes from 'prop-types'
import LayoutContent from './styles'
import Header from './Header'
import Sider from './Sider'
import AlertProvider from '../components/HOC/AlertProvider'

const AppLayout = ({children}) => (
  <Layout style={{minHeight: '968px'}}>
    <AlertProvider />
    <Sider />
    <Layout>
      <Header />
      <LayoutContent>{children}</LayoutContent>
    </Layout>
  </Layout>
)

AppLayout.propTypes = {
  children: PropTypes.node.isRequired,
}

export default AppLayout
