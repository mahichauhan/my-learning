import React from 'react'
import PropTypes from 'prop-types'
import StyledButton from './styled'

function IconButton({children, incons, color}) {
  const Icon = incons
  return (
    <>
      <StyledButton
        shape="round"
        icon={<Icon />}
        size="small"
        color={color}>
        {children}
      </StyledButton>
    </>
  )
}

IconButton.propTypes = {
  children: PropTypes.elementType.isRequired,
  incons: PropTypes.elementType.isRequired,
  color: PropTypes.string,
}

IconButton.defaultProps = {
  color: '',
}

export default IconButton
