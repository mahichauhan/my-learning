import {Row, Anchor} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

const StyledRow = styled(Row)`
  width: 90%;
  & .buttondiv {
    display: flex;
    justify-content: flex-end;
    margin: -1rem !important;
  }
  & .xebiacrp-form-item {
    display: block !important;
  }
  & .xebiacrp-card-body {
    padding: 2rem;
    & .xebiacrp-col.xebiacrp-form-item-label {
      margin-left: 0.5rem !important;
    }
  }
  & .xebiacrp-form-item-label > label {
    display: contents;
    font-weight: 600;
  }
`
export const AnchorStyled = styled(Anchor)({
  color: theme.primaryColor,

  '& .xebiacrp-anchor-link': {
    color: theme.primaryColor,
    fontSize: '1.2rem',
    textDecoration: 'underline',
    padding: 0,

    '& .xebiacrp-anchor-link-title': {
      color: theme.btnColor,
      textTransform: 'uppercase',
      fontWeight: 700,
    },
  },
  '& .xebiacrp-anchor-ink': {
    display: 'none',
  },
})

export default StyledRow
