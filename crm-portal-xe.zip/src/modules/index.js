import HrModule from './HRModule'
import StudentModule from './StudentModule'
import InterviewerModule from './InterviewerModule'

export {HrModule, StudentModule, InterviewerModule}
