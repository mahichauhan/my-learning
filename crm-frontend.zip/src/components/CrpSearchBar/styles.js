import {Button, Space} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

export const SearchButton = styled(Button)({
  width: theme.pxToRem(180),
  backgroundColor: theme.btnColor,
  marginLeft: '1rem',
})

export const FlexSpace = styled(Space)({
  '.xebiacrp-space-item': {
    display: 'flex',
  },
})
