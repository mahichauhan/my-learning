import {EllipsisOutlined} from '@ant-design/icons'
import {Button, Table, Typography} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

export const MainTable = styled(Table)({
  '.xebiacrp-table table': {
    borderCollapse: 'collapse',
  },

  '.xebiacrp-table-thead ': {
    borderStyle: 'hidden',

    '.xebiacrp-table-cell': {
      fontSize: theme.pxToRem(14),
      color: theme.darkGrey,
      backgroundColor: theme.white,
      padding: theme.pxToRem(5),
    },
  },

  '.crp-table-row': {
    borderStyle: 'hidden',
    '.xebiacrp-table-cell': {
      fontSize: theme.pxToRem(14),
      padding: theme.pxToRem(5),
    },
  },

  '.xebiacrp-pagination-item': {
    display: 'none',
  },

  '.xebiacrp-pagination.xebiacrp-table-pagination.xebiacrp-table-pagination-right':
    {
      margin: `${theme.pxToRem(5)} 1rem`,
    },

  '.xebiacrp-pagination-total-text': {
    fontSize: theme.pxToRem(12),
    fontStyle: 'italic',
  },
})

export const TableTitle = styled(Typography.Text)({
  textTransform: 'uppercase',
  color: theme.darkGrey,
  font: `normal normal medium 1rem/1.5rem ${theme.fontFamily}`,
})

export const PaginationLink = styled(Typography.Text)({
  fontSize: theme.pxToRem(12),
  textTransform: 'uppercase',
})

export const TableActionsButton = styled(Button)({
  height: 0,
  padding: 0,
  fontSize: theme.pxToRem(18),
  borderRadius: 0,
})

export const StyledEllipsisOutlined = styled(
  EllipsisOutlined
)({
  color: theme.btnColor,
  fontSize: theme.pxToRem(20),
})
