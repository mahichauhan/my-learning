import React from 'react'
import XHireLogo from '../icons/XHireLogo'

const AppLogo = () => (
  <div className="siderLogo">
    <XHireLogo />
    <p className="campus_recruitment_portal">
      Campus Recruitment Portal
    </p>
  </div>
)

export default AppLogo
