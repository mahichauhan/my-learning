import {Col, Layout} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

export const UserAvatarTitle = styled('ul')`
  list-style: none;
  margin-bottom: 0;
  padding: 0;

  li {
    display: inline;
    color: ${theme.darkGrey};
  }
`

export const HeaderTitle = styled('h1')`
  font-size: 2rem;
  margin-bottom: 1rem;
  margin-left: 2rem;
`

export const LayoutHeader = styled(Layout.Header)`
  margin-top: 38px;
`
export const ColTextEnd = styled(Col)`
  text-align: end;
`

export const ListItemMargin = styled('li')`
  margin-right: 5px;
`
