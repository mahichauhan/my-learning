import React from 'react'

const JobBoardIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="18.88"
    height="18.88"
    viewBox="0 0 18.88 18.88">
    <defs />
    <path
      fill="#fff"
      className="nav-icon-fill"
      d="M6,28v5.035h5.979V28Zm5.349,4.405H6.629V28.629h4.72Z"
      transform="translate(-4.741 -19.819)"
    />
    <circle
      fill="#fff"
      className="nav-icon-fill"
      cx="0.5"
      cy="0.5"
      r="0.5"
      transform="translate(1.655 0.881)"
    />
    <circle
      fill="#fff"
      className="nav-icon-fill"
      cx="0.5"
      cy="0.5"
      r="0.5"
      transform="translate(2.855 0.881)"
    />
    <circle
      fill="#fff"
      className="nav-icon-fill"
      cx="0.5"
      cy="0.5"
      r="0.5"
      transform="translate(4.055 0.881)"
    />
    <path
      fill="#fff"
      className="nav-icon-fill"
      d="M18.587,14H6v3.776H18.587Zm-.629,3.147H6.629V14.629H17.957Z"
      transform="translate(-4.741 -10.224)"
    />
    <rect
      fill="#fff"
      className="nav-icon-fill"
      width="7"
      height="0.8"
      transform="translate(1.655 16.881)"
    />
    <rect
      fill="#fff"
      className="nav-icon-fill"
      width="7"
      height="0.8"
      transform="translate(1.655 13.881)"
    />
    <rect
      fill="#fff"
      className="nav-icon-fill"
      width="7"
      height="0.8"
      transform="translate(1.655 15.381)"
    />
    <path
      fill="#fff"
      className="nav-icon-fill"
      d="M40.5,36.573H38.608v-.629A.927.927,0,0,0,37.664,35H35.776a.927.927,0,0,0-.944.944v.629H32.944a.927.927,0,0,0-.944.944v5.035a.927.927,0,0,0,.944.944H40.5a.927.927,0,0,0,.944-.944V37.517A.927.927,0,0,0,40.5,36.573Zm-5.035-.629a.3.3,0,0,1,.315-.315h1.888a.3.3,0,0,1,.315.315v.629H35.461ZM32.944,37.2H40.5a.3.3,0,0,1,.315.315v2.2H37.664v-.944H35.776v.944H32.629v-2.2A.3.3,0,0,1,32.944,37.2Zm4.091,2.2v1.259h-.629V39.405ZM40.5,42.867H32.944a.3.3,0,0,1-.315-.315v-2.2h3.147v.944h1.888v-.944h3.147v2.2A.3.3,0,0,1,40.5,42.867Z"
      transform="translate(-22.56 -24.616)"
    />
    <path
      fill="#fff"
      className="nav-icon-fill"
      d="M32.979,29.573V28H27v5.035h.944V32.72a1.07,1.07,0,0,1,.031-.315h-.346V28.629h4.72v.944Z"
      transform="translate(-19.133 -19.819)"
    />
    <path
      fill="#fff"
      className="nav-icon-fill"
      d="M2.629,20.251V5.147H16.475v6.608H17.1V2H2V20.88h9.125a1.622,1.622,0,0,1-.283-.629Zm0-17.621H16.475V4.517H2.629Z"
      transform="translate(-2 -2)"
    />
  </svg>
)

export default JobBoardIcon
