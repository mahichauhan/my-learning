import React, {useEffect, useState} from 'react'
import {Badge, Row, Col, Popover} from 'antd'
import {BellOutlined} from '@ant-design/icons'
import Avatars from '../../components/pictures/Avatars'
import {
  HeaderTitle,
  UserAvatarTitle,
  LayoutHeader,
  ColTextEnd,
  ListItemMargin,
} from './styles'
import Navigation from '../../config/navigation'
import UserMenu from './UserMenu'
import NotificationsList from './Notifications'

const Header = () => {
  const headerAvatarSetting = {
    shape: 'square',
    size: 'big',
    path: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
  }

  const [pageTitle, setPageTitle] = useState(
    'Your Dashboard'
  )

  useEffect(() => {
    const currentPagePath = window.location.pathname
    const lastPath = currentPagePath.split('/')
    if (currentPagePath !== '') {
      const currentPage = Navigation.HR.find(
        (navigationItem) =>
          navigationItem.to === currentPagePath
      )
      setPageTitle(
        currentPage
          ? currentPage.title
          : lastPath[lastPath.length - 1]
      )
    }
  }, [window.location.pathname])

  return (
    <>
      <LayoutHeader className="header">
        <Row>
          <Col span={8}>
            <HeaderTitle
              style={{textTransform: 'capitalize'}}>
              {pageTitle}
            </HeaderTitle>
          </Col>
          <Col span={4} offset={12}>
            <Row type="flex" align="middle" justify="end">
              <ColTextEnd span={4}>
                <Popover
                  placement="bottomRight"
                  overlayClassName="header-pop-card notification-hover-card"
                  content={
                    <>
                      <HeaderTitle>
                        Notifications
                      </HeaderTitle>
                      <NotificationsList />
                    </>
                  }>
                  <Badge count={99} size="small">
                    <BellOutlined />
                  </Badge>
                </Popover>
              </ColTextEnd>
              <ColTextEnd flex="auto">
                <Popover
                  placement="bottomRight"
                  overlayClassName="header-pop-card user-hover-card"
                  content={<UserMenu />}>
                  <UserAvatarTitle>
                    <ListItemMargin
                      style={{marginRight: '5px'}}>
                      Hi, Garima Mohan
                    </ListItemMargin>
                    <li>
                      <Avatars
                        useravatar={headerAvatarSetting}
                      />
                    </li>
                  </UserAvatarTitle>
                </Popover>
              </ColTextEnd>
            </Row>
          </Col>
        </Row>
      </LayoutHeader>
    </>
  )
}

export default Header
