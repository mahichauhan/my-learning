import axios from 'axios'

export default (history = null) => {
  const baseURL = process.env.BASEURL
  const headers = {}

  const axiosInstance = axios.create({
    baseURL: baseURL,
    headers,
  })

  return axiosInstance
}
