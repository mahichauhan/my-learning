import React from 'react'
import {
  Route,
  BrowserRouter as Router,
  Switch,
  Redirect,
} from 'react-router-dom'
import './assets/styles/xebiacrp-antd.css'
import './assets/styles/index.scss'
import APP_ROUTES from './config/app.routes'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import PrivateRoute from './routes/PrivateRoute'
import PublicRoute from './routes/PublicRoute'
import {
  HrModule,
  StudentModule,
  InterviewerModule,
} from './modules'

const App = () => (
  <Router>
    <Switch>
      <Route exact path="/">
        <Redirect to={APP_ROUTES.HOMEPAGE} />
      </Route>
      <Route>
        {/* Login Page Route */}
        <PublicRoute
          exact
          path={APP_ROUTES.LOGINPAGE}
          component={Login}
        />

        {/* Dashboard Page Route */}
        <PrivateRoute
          exact
          restricted
          path={APP_ROUTES.HOMEPAGE}
          component={Dashboard}>
          <Redirect
            to={
              APP_ROUTES.HR_MODULE.ROOT +
              APP_ROUTES.HR_MODULE.DASHBOARD
            }
          />
        </PrivateRoute>
        <PrivateRoute
          restricted
          path={APP_ROUTES.STUDENT_MODULE.ROOT}
          component={StudentModule}
        />
        <PrivateRoute
          restricted
          path={APP_ROUTES.HR_MODULE.ROOT}
          component={HrModule}
        />
        <PrivateRoute
          restricted
          path={APP_ROUTES.INTERVIEWER_MODULE.ROOT}
          component={InterviewerModule}
        />
      </Route>
    </Switch>
  </Router>
)

export default App
