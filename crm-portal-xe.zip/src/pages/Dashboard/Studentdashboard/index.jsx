import React from 'react'
import styled from 'styled-components'
import AppLayout from '../../../layout'
// import theme from '../../../config/Theme'

const StyledStudendDashboard = styled('div')`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
`

const StudendDashboard = () => (
  <AppLayout>
    <StyledStudendDashboard>
      <h2>Student dashboard </h2>
    </StyledStudendDashboard>
  </AppLayout>
)

export default StudendDashboard
