import {actionType} from '../actions/actionTypes'

const initialState = {}

const UserReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionType.UserActionType
      .SET_LOGGED_IN_USER_REDUCER:
      return {
        ...state,
        loggedInUserDetails: action.payload,
      }
    default:
      return state
  }
}

export default UserReducer
