import API_ROUTES from '../config/api_routes'
import crpAxios from '../config/axios'

class JobsService {
  static createJob = (job) => {
    return crpAxios.post(API_ROUTES.JOBS.ROOT, job)
  }
}

export default JobsService
