import React from 'react'
import PropTypes from 'prop-types'

HrSettings.propTypes = {}

function HrSettings(props) {
  return (
    <>
      <h2>setting page</h2>
    </>
  )
}

export default HrSettings
