import React from 'react'
import {CrpCard, CrpSelectField} from '../../../components'
import {
  Timeline,
  Typography,
  Badge,
  Divider,
  Col,
  Row,
  Select,
} from 'antd'
import {
  ClockCircleOutlined,
  LoadingOutlined,
} from '@ant-design/icons'
import theme from '../../../config/theme'
import styled from 'styled-components'
// import CrpSelect from '../../../components/CrpSelectField'

const CrpDivider = styled(Divider)`
  & .crp-divider {
    color: theme.black,
    fontSize: theme.pxToRem(14),
    fontWeight : 'bold'
  }
`
const CrpBadge = styled(Badge)`
    color: theme.black,
}`
const interviwData = ['xbhjbhj', 'hygyugu', 'hgbhb']
const CrpInterviewPool = (props) => (
  <>
    <CrpCard width="auto" borderRadius={4}>
      <div style={{marginLeft: 20}}>
        <Typography.Text
          style={{
            color: theme.black,
            fontSize: theme.pxToRem(16),
          }}>
          {props.interviewHead}
        </Typography.Text>
        <div style={{marginTop: 10}}>
          <CrpSelectField
            placeholder="Location"
            onChange={(e) => setFieldValue('location', e)}
            name="location"
            bordered={false}
            value={'L1 Interviewer'}>
            <Select.Option value="Noida">
              L2 Interviewer
            </Select.Option>
            <Select.Option value="Pune">
              Executives
            </Select.Option>
          </CrpSelectField>
        </div>
        <div style={{marginTop: 20}}>
          <Typography.Text
            style={{
              color: theme.black,
              fontSize: theme.pxToRem(16),
            }}>
            {props.interviewSubHead}
          </Typography.Text>
          <div style={{marginTop: 10}}>
            {props.data.map((val) => (
              <Row key={val.key} style={{marginTop: 3}}>
                <CrpBadge color={theme.purpleColor} />
                <Typography.Text
                  style={{
                    color: theme.grey,
                    fontSize: theme.pxToRem(12),
                  }}>
                  {val.title}
                </Typography.Text>
              </Row>
            ))}
          </div>
        </div>
      </div>
    </CrpCard>
  </>
)

export default CrpInterviewPool
