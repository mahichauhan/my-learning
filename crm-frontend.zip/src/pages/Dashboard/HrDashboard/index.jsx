import React from 'react'
import {Col, Row, Typography} from 'antd'
import CrpStatisticsCard from '../../../components/CrpStatisticsCard'
import {CrpTable, CrpCard} from '../../../components'
import theme from '../../../config/theme'
import interviewsScheduledToday from '../../../assets/dummy-data/dashboard/interviewsScheduledToday.json'
import interviewToBeScheduled from '../../../assets/dummy-data/dashboard/interviewToBeScheduled.json'
import CrpActivity from './CrpActivity'
import CrpInterviewPool from './CrpInterviewPool'

const columns = [
  {
    title: 'Candidate Name',
    dataIndex: 'candidateName',
    key: 'candidateName',
  },
  {
    title: 'Interview Round',
    dataIndex: 'interviewRound',
    key: 'interviewRound',
  },
  {
    title: 'Time',
    dataIndex: 'time',
    key: 'time',
  },
  {
    title: 'Interviewer Name',
    dataIndex: 'interviewerName',
    key: 'interviewerName',
  },
  {
    title: 'Position Applied',
    dataIndex: 'positionApplied',
    key: 'positionApplied',
  },
]

const columnsInterviewTobeScheduled = [
  {
    title: 'Candidate Name',
    dataIndex: 'candidateName',
    key: 'candidateName',
  },
  {
    title: 'CGPA',
    dataIndex: 'cgpa',
    key: 'cgpa',
  },
  {
    title: 'Course/Specialisation',
    dataIndex: 'course',
    key: 'course',
  },
  {
    title: 'Position Applied',
    dataIndex: 'positionApplied',
    key: 'positionApplied',
  },
  {
    title: 'Interview Round',
    dataIndex: 'interviewRound',
    key: 'interviewRound',
  },
  {
    title: 'Next Interview',
    dataIndex: 'nextInterview',
    key: 'nextInterview',
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    render: (text, _record, _index) => {
      let textColor = theme.primaryColor

      if (text === 'L1 CLEARED') {
        textColor = theme.greenYellow
      } else if (text === 'L2 CLEARED') {
        textColor = theme.orange
      }
      return (
        <Typography.Text style={{color: textColor}}>
          {text}
        </Typography.Text>
      )
    },
  },
]

const activityData = [
  {
    title: 'New student Registered : Shivam Dube',
    time: '1 min ago',
    desc: 'by Shambhavi Mishra',
  },
  {
    title: 'New student Registered : Shivam Dube',
    time: '1 min ago',
    desc: 'by Shambhavi Mishra',
  },
  {
    title: 'New student Registered : Shivam Dube',
    time: '1 min ago',
    desc: 'by Shambhavi Mishra',
  },
  {
    title: 'New student Registered : Shivam Dube',
    time: '1 min ago',
    desc: 'by Shambhavi Mishra',
  },
  {
    title: 'New student Registered : Shivam Dube',
    time: '1 min ago',
    desc: 'by Shambhavi Mishra',
  },
  {
    title: 'New student Registered : Shivam Dube',
    time: '1 min ago',
    desc: 'by Shambhavi Mishra',
  },
  {
    title: 'New student Registered : Shivam Dube',
    time: '1 min ago',
    desc: 'by Shambhavi Mishra',
  },
]

const interviwData = [
  {
    title: 'Priynaka Garg',
    value: '1',
  },
  {
    title: 'Avinash Singh',
    value: '2',
  },
  {
    title: 'Shweta Singh',
    value: '3',
  },
  {
    title: 'Ishani Dubey',
    value: '4',
  },
  {
    title: 'Ishani Dubey',
    value: '5',
  },
  {
    title: 'Ishani Dubey',
    value: '6',
  },
  {
    title: 'Ishani Dubey',
    value: '7',
  },
  {
    title: 'Avinash Singh',
    value: '2',
  },
  {
    title: 'Avinash Singh',
    value: '2',
  },
]

const HrDashboard = () => (
  <>
    <Row gutter={[16, 10]}>
      <Col span="18">
        <Row gutter={[16, 10]}>
          <Col span={8}>
            <CrpStatisticsCard
              title={'NO OF INTERVIEW TO BE SCHEDULED'}
              value={132}
              type="increasing"
              parcentage={12}
              subTitle={'in the last month'}
              currentMonth={'(CURRENT MONTH)'}
            />
          </Col>
          <Col span={8}>
            <CrpStatisticsCard
              title={'NO OF INTERVIEW TO BE SCHEDULED'}
              value={64}
              type="increasing"
              parcentage={12}
              subTitle={'in the last month'}
              currentMonth={'(CURRENT MONTH)'}
            />
          </Col>
          <Col span={8}>
            <CrpStatisticsCard
              title={'NO OF INTERVIEW TO BE SCHEDULED'}
              value={43}
              type="increasing"
              parcentage={12}
              subTitle={'in the last month'}
              currentMonth={'(CURRENT MONTH)'}
            />
          </Col>
        </Row>
        <Row
          gutter={[16, 10]}
          style={{marginTop: theme.pxToRem(20)}}>
          <Col span={8}>
            <Row gutter={[16, 10]}>
              <Col>
                <CrpStatisticsCard
                  title={'NO OF INTERVIEW TO BE SCHEDULED'}
                  value={17}
                  parcentage={3}
                  subTitle={'in the last month'}
                  currentMonth={'(CURRENT MONTH)'}
                />
              </Col>
              <Col style={{marginTop: theme.pxToRem(10)}}>
                <CrpStatisticsCard
                  title={'NO OF INTERVIEW TO BE SCHEDULED'}
                  value={8}
                  parcentage={1}
                  subTitle={'in the last month'}
                  currentMonth={'(CURRENT MONTH)'}
                />
              </Col>
            </Row>
          </Col>
          <Col span={16}>
            <Col>
              <CrpCard width="auto">
                <CrpTable
                  title={'Interviews Scheduled today'}
                  dataSource={interviewsScheduledToday}
                  columns={columns}
                />
              </CrpCard>
            </Col>
          </Col>
        </Row>
        <Row
          gutter={[16, 10]}
          style={{marginTop: theme.pxToRem(20)}}>
          <Col span={24}>
            <CrpCard width="auto">
              <CrpTable
                title={'Interviews to be Scheduled'}
                dataSource={interviewToBeScheduled}
                columns={columnsInterviewTobeScheduled}
              />
            </CrpCard>
          </Col>
        </Row>
        <Row
          gutter={[16, 10]}
          style={{marginTop: theme.pxToRem(20)}}>
          <Col span={16}>
            <Row gutter={[16, 10]}>
              <Col span={24}>
                <CrpCard width="auto" borderRadius={4}>
                  <h1>Bar Chart Card</h1>
                </CrpCard>
              </Col>
            </Row>
          </Col>
          <Col span={8}>
            <Col>
              <CrpStatisticsCard
                title={'CANDIDATES REGISTERED TODAY'}
                value={17}
                parcentage={3}
                subTitle={'yesterday'}
                currentMonth={''}
              />
            </Col>
            <Col style={{marginTop: theme.pxToRem(20)}}>
              <CrpStatisticsCard
                title={'NO OF OPEN POSITIONS'}
                value={12}
                parcentage={3}
                subTitle={'in the last week'}
                currentMonth={''}
              />
            </Col>
          </Col>
        </Row>
      </Col>
      <Col span="6">
        <CrpActivity
          activityHead={'Activity'}
          data={activityData}
        />
        {/* <div style={{marginTop: 10}}>
          <CrpInterviewPool
            interviewHead={'Interviewer’s Pool'}
            interviewSubHead={'L1 Interviewer'}
            data={interviwData}
          />
        </div> */}
      </Col>
    </Row>
  </>
)

export default HrDashboard
