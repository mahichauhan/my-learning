import React from 'react'
import {Avatar, Image} from 'antd'
import PropTypes from 'prop-types'

const Avatars = (props) => {
  // eslint-disable-next-line react/prop-types
  const {userAvatar} = props

  return (
    <>
      <Avatar
        // eslint-disable-next-line react/prop-types
        shape={userAvatar.shape}
        // eslint-disable-next-line react/prop-types
        size={userAvatar.size}
        // eslint-disable-next-line react/prop-types
        src={
          <Image
            src={`${userAvatar.path}`}
            preview={false}
          />
        }
      />
    </>
  )
}

Avatar.defaultProps = {
  userAvatar: PropTypes.shape({
    shape: 'square',
    size: 'big',
    path: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
  }),
}

Avatars.prototype = {
  userAvatar: PropTypes.shape({
    shape: PropTypes.string,
    size: PropTypes.string,
    path: PropTypes.string,
  }),
}

export default Avatars
