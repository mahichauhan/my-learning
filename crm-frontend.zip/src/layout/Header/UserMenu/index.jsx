import React from 'react'
import {
  LogoutOutlined,
  SettingOutlined,
  UserOutlined,
} from '@ant-design/icons'
import {StyledUserMenu, StyledUserMenuItem} from './styles'
import {useHistory} from 'react-router-dom'
import theme from '../../../config/theme'
import constants from '../../../config/constants'
import APP_ROUTES from '../../../config/app.routes'

const {HR_MODULE} = APP_ROUTES

const UserMenu = () => {
  const history = useHistory()
  const handleMenuClick = (e) => {
    if (e.key === constants.USER_MENU.PROFILE) {
      history.push(HR_MODULE.ROOT + HR_MODULE.PROFILE)
    }
  }
  return (
    <StyledUserMenu
      mode={'inline'}
      theme={'light'}
      selectable={false}
      onClick={handleMenuClick}>
      <StyledUserMenuItem
        key={constants.USER_MENU.PROFILE}
        icon={
          <UserOutlined style={{color: theme.arrowColor}} />
        }>
        {constants.USER_MENU.PROFILE}
      </StyledUserMenuItem>
      <StyledUserMenuItem
        key={constants.USER_MENU.SETTINGS}
        icon={
          <SettingOutlined
            style={{color: theme.arrowColor}}
          />
        }>
        {constants.USER_MENU.SETTINGS}
      </StyledUserMenuItem>
      <StyledUserMenuItem
        key={constants.USER_MENU.LOGOUT}
        icon={
          <LogoutOutlined
            style={{color: theme.arrowColor}}
          />
        }
        onClick={() => console.log('Logout')}>
        {constants.USER_MENU.LOGOUT}
      </StyledUserMenuItem>
    </StyledUserMenu>
  )
}

export default UserMenu
