import {Input} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

const InputStyled = styled(Input)`
  width: 100%;
  height: 3rem;
  padding: 1rem;
  border-radius: 0.5rem 0.5rem 0rem 0rem;
  border: none;
  border-bottom: 1px solid ${theme.inputBottomBorder};
  box-shadow: none;
  font: normal normal medium;
  box-sizing: border-box;
  color: ${theme.inputColor};
  font-weight: ${theme.fontWeight};
  ::placeholder,
  ::-webkit-input-placeholder {
    color: ${theme.placeholderColor};
    opacity: 0.3;
  }
  :-ms-input-placeholder {
    color: ${theme.placeholderColor};
    opacity: 0.3;
  }
  &:hover {
    border: none;
    border-bottom: 1px solid ${theme.inputBottomBorder};
    box-shadow: none;
  }
  &:focus {
    border-bottom: 1px solid ${theme.inputBottomBorder};
    box-shadow: none;
    color: ${theme.black};
    font-weight: ${theme.fontWeight};
  }
`
export default InputStyled
