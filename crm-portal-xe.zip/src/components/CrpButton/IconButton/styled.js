import {Button} from 'antd'
import styled from 'styled-components'
import theme from '../../../config/theme'

const ButtonStyled = styled(Button)`
  color: ${(props) =>
    props.color ? props.color : theme.btnColor};
  font-weight: 500;
  text-transform: uppercase;
  font-size: ${theme.spacing(3)}px;
  border-radius: ${theme.spacing(3)}px;
  letter-spacing: 0.13px;
  border: none;
  box-shadow: none;
  & span {
    margin-right: ${theme.spacing(1 / 2)}px;
  }
  &:hover {
    background: ${theme.hoverBtnBackground};
    color: ${theme.btnHoverColor};
  }
`
export default ButtonStyled
