import {Layout, Menu} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

export const AppSider = styled(Layout.Sider)`
  width: 276px !important;
  flex: 0 0 276px !important;
  max-width: initial !important;
  min-width: 276px !important;
  .siderLogo {
    text-align: center;
    margin-top: ${theme.pxToRem(38)};

    .campus_recruitment_portal {
      text-align: center;
      margin-top: ${theme.pxToRem(-10)};
    }
  }
  .campus_recruitment_portal {
    font: var(--unnamed-font-style-normal) normal bold
      var(--unnamed-font-size-14) / 36px
      var(--unnamed-font-family-ubuntu);
    letter-spacing: var(--unnamed-character-spacing-0);
    color: var(--unnamed-color-ffffff);
    text-align: left;
    font: normal normal bold 14px/36px Ubuntu;
    letter-spacing: 0px;
    color: #ffffff;
    opacity: 1;
  }
`

export const AppMenu = styled(Menu)`
  margin-top: 3rem;
  background-color: ${theme.primaryColor};

  .xebiacrp-menu-item {
    padding-left: 1rem;
    background-color: ${theme.primaryColor};
    display: flex;
    align-items: center;
    transition: none;
    display: grid;
    grid-template-columns: 0.2fr 1fr;

    svg {
      margin-left: 1rem;
    }

    span a {
      font-size: 0.875rem;
      margin-left: 1.5rem;
      color: ${theme.white} !important;
    }
  }

  .xebiacrp-menu-item-selected {
    background-color: ${theme.white} !important;
    border-radius: 0px 1.5rem 1.5rem 0px;
    width: 262px;
    &::after {
      content: none;
    }

    .nav-icon-fill {
      fill: ${theme.primaryColor};
    }
    span a {
      color: ${theme.primaryColor} !important;
      font-weight: 1000;
    }
  }
`
