import HomeIcon from './HomeIcon'
import Candidatesicon from './Candidatesicon'
import CampusIcon from './CampusIcon'
import OpenJobsIcon from './OpenJobsIcon'
import JobBoardIcon from './JobBoardIcon'
import InterviewIcon from './InterviewIcon'
import ReportIcon from './ReportIcon'

const icons = {
  HomeIcon,
  Candidatesicon,
  CampusIcon,
  OpenJobsIcon,
  JobBoardIcon,
  InterviewIcon,
  ReportIcon,
}

export default icons
