import {applyMiddleware, createStore, compose} from 'redux'
import {createLogger} from 'redux-logger'
import createSagaMiddleware from 'redux-saga'
import RootReducer from './reducers/index'
import rootSaga from './sagas/index'
import constants from '../config/constants'

const logger = createLogger({
  collapsed: true,
})

export default function configureStore() {
  const sagaMiddleware = createSagaMiddleware()

  const getMiddleware = () => {
    if (process.env.NODE_ENV === constants.APP_RUNNING_ON) {
      // return applyMiddleware(sagaMiddleware, logger)
      return applyMiddleware(sagaMiddleware, logger)
    }
    return applyMiddleware(sagaMiddleware)
  }

  /* eslint-disable no-underscore-dangle */
  const composeEnhancers =
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose
  const store = createStore(
    RootReducer,
    composeEnhancers(getMiddleware())
  )
  /* eslint-enable */

  sagaMiddleware.run(rootSaga)

  return store
}
