import {Layout} from 'antd'
import styled from 'styled-components'
import ThemeStyle from '../config/theme'

const LayoutContent = styled(Layout.Content)`
  margin: ${ThemeStyle.margine};
  background: ${ThemeStyle.contentBg};
  padding: ${ThemeStyle.menuPadding};
  minheight: ${ThemeStyle.minheight};
`

export default LayoutContent
