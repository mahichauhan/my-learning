import {Row, Col, Space, Button} from 'antd'
import React from 'react'
import CrpInputField from '../CrpInputField'
import SearchIcon from '../icons/SearchIcon'
import {FlexSpace, SearchButton} from './styles'

const CrpSearchBar = (props) => {
  return (
    <Row align="middle">
      <Col span={16}>
        <CrpInputField {...props} size="large" />
      </Col>
      <Col span={3}>
        <SearchButton type={props.buttonType}>
          <FlexSpace align="center" size="middle">
            <SearchIcon />
            <span>SEARCH</span>
          </FlexSpace>
        </SearchButton>
      </Col>
    </Row>
  )
}

export default CrpSearchBar
