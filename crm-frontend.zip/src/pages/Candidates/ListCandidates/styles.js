import {Row, Col, Button} from 'antd'
import styled from 'styled-components'
import theme from '../../../config/theme'
import {EllipsisOutlined} from '@ant-design/icons'

export const StyledRow = styled(Row)({
  marginBottom: '2rem',
})

export const SearchContainer = styled(Col)({
  marginLeft: '0.6rem',
})

export const StyledUl = styled('ul')({
  listStyle: 'none',
  paddingLeft: theme.pxToRem(10),
  marginBottom: theme.pxToRem(3),

  '.xebiacrp-btn': {
    padding: `0 ${theme.pxToRem(10)}`,
    height: theme.pxToRem(10),
    span: {
      fontSize: theme.pxToRem(14),
      color: theme.darkGrey,
    },
  },
})
