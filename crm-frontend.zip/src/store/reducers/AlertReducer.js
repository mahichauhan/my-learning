import {actionType} from '../actions/actionTypes'

const initialAlert = {}

const AlertReducer = (state = initialAlert, action) => {
  switch (action.type) {
    case actionType.AlertActionType.ADD_ALERT:
      return {...state, ...action.payload}
      break
    case actionType.AlertActionType.REMOVE_ALERT:
      return {}
      break
    default:
      return {...state}
      break
  }
}

export default AlertReducer
