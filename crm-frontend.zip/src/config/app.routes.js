const APP_ROUTES = {
  HOMEPAGE: '/home',
  LOGINPAGE: '/login',
  STUDENT_MODULE: {
    ROOT: '/students',
    DASHBOARD: '/dashboard',
  },
  HR_MODULE: {
    ROOT: '/hr',
    DASHBOARD: '/dashboard',
    CAMPUSES: {
      ROOT: '/campuses',
      ADD: '/add',
    },
    CANDIDATES: {
      ROOT: '/candidates',
    },
    JOBS: {
      ROOT: '/jobs',
      BOARD: '/board',
      ADD: '/add',
    },
    USERS: {
      SETTINGS: '/settings',
      PROFILE: '/profile',
    },
    INTERVIEWS: {
      ROOT: '/interviews',
    },
    REPORTS: '/reports',
  },
  INTERVIEWER_MODULE: {
    ROOT: '/interviewer',
    DASHBOARD: '/dashboard',
  },
  DASHBOARD: '/dashboard',
}

export default APP_ROUTES
