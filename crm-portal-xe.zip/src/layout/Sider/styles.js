import {Layout, Menu} from 'antd'
import {NavLink} from 'react-router-dom'
import styled from 'styled-components'
import theme from '../../config/theme'

export const AppSider = styled(Layout.Sider)`
  width: 276px !important;
  flex: 0 0 276px !important;
  max-width: initial !important;
  min-width: 276px !important;
  .siderLogo {
    text-align: center;
    .sideLogoImage {
      width: 184px;
      height: 16px;
    }
    .campus_recruitment_portal {
      text-align: center;
    }
  }
  .campus_recruitment_portal {
    font: var(--unnamed-font-style-normal) normal bold
      var(--unnamed-font-size-14) / 36px
      var(--unnamed-font-family-ubuntu);
    letter-spacing: var(--unnamed-character-spacing-0);
    color: var(--unnamed-color-ffffff);
    text-align: left;
    font: normal normal bold 14px/36px Ubuntu;
    letter-spacing: 0px;
    color: #ffffff;
    opacity: 1;
  }
`

export const AppMenu = styled(Menu)`
  margin-top: 3rem;
  background-color: ${theme.primaryColor};

  .xebiacrp-menu-item {
    padding-left: 1rem;
    background-color: ${theme.primaryColor};
    display: flex;
    align-items: center;

    svg {
      margin-left: 1rem;
    }

    span {
      font-size: 0.875rem;
      margin-left: 1.5rem;
      color: #ffffff;
    }
  }

  .xebiacrp-menu-item-selected {
    background-color: #ffffff !important;
    border-radius: 0px 1.5rem 1.5rem 0px;
    width: 262px;

    &::after {
      content: none;
    }

    .nav-icon-fill {
      fill: #19237e;
    }
    span {
      color: #19237e;
      font-weight: 1000;
    }
  }
`
export const LinkStyled = styled(NavLink)`
  color: #fff !important;
  & :hover {
    color: #19237e !important;
  }
`
