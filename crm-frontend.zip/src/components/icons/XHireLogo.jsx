import React from 'react'

const XHireLogo = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="73"
      height="40"
      viewBox="0 0 73 40">
      <text className="logo-x" transform="translate(0 33)">
        <tspan x="0" y="0">
          X
        </tspan>
        <tspan className="logo-h" y="0">
          H
        </tspan>
        <tspan className="logo-ire" y="0">
          ire
        </tspan>
      </text>
    </svg>
  )
}

export default XHireLogo
