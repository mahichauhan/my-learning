import {DatePicker} from 'antd'
import styled, {
  css,
  createGlobalStyle,
} from 'styled-components'
import theme from '../../config/theme'
const baseInputStyles = css`
  width: 100%;
  height: 3rem;
  padding: 1rem;
  border-radius: 0.5rem 0.5rem 0rem 0rem;
  background: #e9e9f8;
  color: ${theme.placeholderColor};
  border: none;
  border-bottom: 1px solid ${theme.inputBottomBorder};
  box-shadow: none;
  font: normal normal medium;
  box-sizing: border-box;
  color: ${theme.black};
  font-weight: ${theme.fontWeight};
  ::placeholder,
  ::-webkit-input-placeholder {
    color: ${theme.placeholderColor};
    opacity: 0.3;
  }
  :-ms-input-placeholder {
    color: ${theme.placeholderColor};
    opacity: 0.3;
  }
`

export const DivStyled = styled('div')`
  background: red;
`

const DatePickerStyled = styled(DatePicker)`
  ${baseInputStyles}
`

export default DatePickerStyled
