import React from 'react'
import {Space, Popover} from 'antd'
import {
  LeftOutlined,
  RightOutlined,
} from '@ant-design/icons'
import {
  MainTable,
  TableTitle,
  PaginationLink,
  StyledEllipsisOutlined,
  TableActionsButton,
} from './styles'
import CrpCard from '../CrpCard'

const PaginateLink = (props) => {
  return (
    <Space>
      {props.text === 'Previous' && props.icon}
      <PaginationLink>{props.text}</PaginationLink>
      {props.text === 'Next' && props.icon}
    </Space>
  )
}

const getActionColumn = (actionList) => ({
  title: '',
  dataIndex: 'nextInterview',
  key: 'nextInterview',
  render: () => (
    <Popover
      placement="bottomRight"
      overlayClassName="header-pop-card table-actions"
      trigger="click"
      content={actionList}>
      <TableActionsButton type="text" size="small">
        <StyledEllipsisOutlined rotate={90} />
      </TableActionsButton>
    </Popover>
  ),
})

const CrpTable = (props) => {
  const itemRender = (_current, type, originalElement) => {
    if (type === 'prev') {
      return (
        <a style={{marginRight: '1.5rem'}}>
          <PaginateLink
            icon={<LeftOutlined />}
            text="Previous"
          />
        </a>
      )
    }
    if (type === 'next') {
      return (
        <a>
          <PaginateLink
            icon={<RightOutlined />}
            text="Next"
          />
        </a>
      )
    }
    return originalElement
  }

  const actionColumn = getActionColumn(props.actionList)
  const columns = props.actionList
    ? [...props.columns, actionColumn]
    : props.columns

  return (
    <MainTable
      dataSource={props.dataSource}
      columns={columns}
      title={() => <TableTitle>{props.title}</TableTitle>}
      bordered={false}
      pagination={{
        size: 'small',
        pageSize: props.pageSize || 5,
        showLessItems: true,
        showSizeChanger: false,
        itemRender,
        showTotal: (total, range) =>
          `Showing ${range[0]}-${range[1]} of ${total} items`,
      }}
      rowClassName={'crp-table-row'}
    />
  )
}

export default CrpTable
