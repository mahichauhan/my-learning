import {Button, Typography} from 'antd'
import React from 'react'
import notifications from '../../../assets/dummy-data/notifications/notifications.json'
import {NotficationListItem} from './styles'

const NotificationsList = () => (
  <ul>
    {notifications.map((notification, ind) => {
      return (
        <NotficationListItem key={ind}>
          <Typography.Paragraph>
            {notification.title}
          </Typography.Paragraph>
          <Button type="link">View Details</Button>
          <Typography.Paragraph className="activity-time">
            {notification.activityTime}
          </Typography.Paragraph>
        </NotficationListItem>
      )
    })}
  </ul>
)

export default NotificationsList
