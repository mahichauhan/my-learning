const APP_ROUTES = {
  HOMEPAGE: '/home',
  LOGINPAGE: '/login',
  STUDENT_MODULE: {
    ROOT: '/students',
    DASHBOARD: '/dashboard',
  },
  HR_MODULE: {
    ROOT: '/hr',
    DASHBOARD: '/dashboard',
    ADDCAMPUS: '/add-campus',
  },
  INTERVIEWER_MODULE: {
    ROOT: '/interviewer',
    DASHBOARD: '/dashboard',
  },
  DASHBOARD: '/dashboard',
}

export default APP_ROUTES
