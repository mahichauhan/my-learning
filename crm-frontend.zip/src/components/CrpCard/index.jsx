import React from 'react'
import PropTypes from 'prop-types'

import {Card} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

const StyledCard = styled(Card)`
  box-shadow: 0px 3px 21px ${theme.boxshadowColor};
  padding: 12px;
`

const CrpCard = ({
  width,
  children,
  borderRadius,
  height,
}) => (
  <div className="site-card-border-less-wrapper">
    <StyledCard
      bordered
      size="small"
      main="green"
      style={{
        width,
        borderRadius: theme.spacing(borderRadius),
        height,
      }}>
      {children}
    </StyledCard>
  </div>
)

CrpCard.propTypes = {
  width: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
  children: PropTypes.oneOfType([
    PropTypes.elementType,
    PropTypes.node,
    PropTypes.array,
    PropTypes.object,
  ]).isRequired,
  borderRadius: PropTypes.number,
  height: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
}

CrpCard.defaultProps = {
  width: 300,
  borderRadius: 5,
  height: 'auto',
}

export default CrpCard
