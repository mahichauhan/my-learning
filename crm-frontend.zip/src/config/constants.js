const constants = {
  APP_RUNNING_ON: 'DEVELOPMENT',
  USER_MENU: {
    PROFILE: 'Profile',
    SETTINGS: 'Settings',
    LOGOUT: 'Logout',
  },
  NAVIGATION_TYPE: {
    SIDER: 'sider',
    USER_MENU: 'userMenu',
  },
}

export default constants
