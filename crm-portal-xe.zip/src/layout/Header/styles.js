import {Menu} from 'antd'
import styled from 'styled-components'
import ThemeStyle from '../../config/theme'

const HeaderMenu = styled(Menu)`
  margin: ${ThemeStyle.margine};
  padding: ${ThemeStyle.menuPadding};
  minheight: ${ThemeStyle.minheight};
  color: #353536 !important;
  .xebiacrp-menu-item-only-child:hover {
    background-color: ${ThemeStyle.backGroundColor} !important;
    color: ${ThemeStyle.menuColor};
  }
  .xebiacrp-menu-item-selected {
    background-color: ${ThemeStyle.backGroundColor} !important;
    color: ${ThemeStyle.menuColor};
  }
  .xebiacrp-menu-item-only-child {
    color: ${ThemeStyle.menuColor};
  }
`
export default HeaderMenu
