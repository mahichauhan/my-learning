import React from 'react'
import SiderLogo from '../../assets/images/XHire.svg'

const AppLogo = () => (
  <div className="siderLogo">
    <img
      className="sideLogoImage"
      src={SiderLogo}
      alt="Sider Logo"
    />
    <p className="campus_recruitment_portal">
      Campus Recruitment Portal
    </p>
  </div>
)

export default AppLogo
