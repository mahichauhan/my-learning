import {Row, Col} from 'antd'
import styled from 'styled-components'

export const StyledRow = styled(Row)({
  marginBottom: '2rem',
})

export const SearchContainer = styled(Col)({
  marginLeft: '0.6rem',
})
