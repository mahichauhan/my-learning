import React from 'react'
import PropTypes from 'prop-types'
import InputStyled, {
  TextAreaStyled,
  SelectStyled,
} from './styled'
import theme from '../../config/theme'

const CrpInputField = (props) => {
  return <InputStyled {...props} />
}

CrpInputField.propTypes = {
  placeholder: PropTypes.string,
}

CrpInputField.defaultProps = {
  placeholder: '',
}

export const CrpTextAreaField = (props) => {
  return <TextAreaStyled {...props} />
}

export const CrpSelectField = (props) => {
  return (
    <SelectStyled
      {...props}
      dropdownStyle={{
        paddingLeft: theme.spacing(2.5),
        paddingRight: theme.spacing(1.5),
        borderRadius: `0rem 0rem ${theme.spacing(
          5
        )}px ${theme.spacing(5)}px`,
        boxShadow: `0px ${theme.spacing(
          1 / 2
        )} ${theme.spacing(2.5)}px ${
          theme.selectDropdwonColor
        }`,
      }}
    />
  )
}

export default CrpInputField
