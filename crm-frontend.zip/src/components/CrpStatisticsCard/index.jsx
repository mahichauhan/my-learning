import React from 'react'
import {Col, Row, Typography} from 'antd'
import {
  CaretUpOutlined,
  CaretDownOutlined,
} from '@ant-design/icons'
import {TextView, StyledRow, HighlightText} from './styles'
import theme from '../../config/theme'
import CrpCard from '../CrpCard'

const {Text} = Typography

const CrpStatisticsCard = (props) => (
  <>
    <CrpCard width="auto" borderRadius={4}>
      <StyledRow>
        <Col span={24}>
          <TextView>
            {props.title} {props.currentMonth}
          </TextView>
        </Col>
      </StyledRow>
      <Row align="middle">
        <Col
          span={12}
          style={{textAlign: 'center', marginLeft: -19}}>
          <HighlightText>{props.value}</HighlightText>
        </Col>
        <Col span={12}>
          <Row>
            <Col span={8}>
              <Text
                style={{
                  color:
                    props.type === 'increasing'
                      ? theme.green
                      : theme.dangerColor,
                  fontSize: theme.pxToRem(15),
                }}>
                {props.type === 'increasing' ? '+' : '-'}
                {props.parcentage}%
              </Text>
            </Col>
            <Col span={12}>
              {props.type === 'increasing' ? (
                <CaretUpOutlined
                  style={{color: `${theme.green}`}}
                />
              ) : (
                <CaretDownOutlined
                  style={{color: `${theme.dangerColor}`}}
                />
              )}
            </Col>
          </Row>
          <div style={{marginTop: '-2px'}}>
            <Col>
              <Text
                style={{
                  color: `${theme.grey}`,
                  fontSize: theme.pxToRem(14),
                  fontWeight: 700,
                }}>
                {props.subTitle}
              </Text>
            </Col>
          </div>
        </Col>
      </Row>
    </CrpCard>
  </>
)

export default CrpStatisticsCard
