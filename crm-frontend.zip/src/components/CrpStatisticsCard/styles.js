import {Row, Typography} from 'antd'
import styled from 'styled-components'
import theme from '../../config/theme'

const {Text} = Typography

export const TextView = styled(Text)`
  color: ${theme.black};
`
export const StyledRow = styled(Row)({
  alignItems: 'center',
  marginTop: '-10px',
})

export const HighlightText = styled(Text)({
  color: theme.iceberg,
  fontSize: theme.pxToRem(40),
})
