import {Row} from 'antd'
import styled from 'styled-components'

const StyledRow = styled(Row)`
  width: 90%;
  & .buttondiv {
    display: flex;
    justify-content: flex-end;
    margin: -1rem !important;
  }
  & .xebiacrp-form-item {
    display: block !important;
  }
  & .xebiacrp-card-body {
    padding: 2rem;
    & .xebiacrp-col.xebiacrp-form-item-label {
      margin-left: 0.5rem !important;
    }
  }
  & .xebiacrp-form-item-label > label {
    display: contents;
    font-weight: 600;
  }
`

export default StyledRow
