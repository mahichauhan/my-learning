import axios from 'axios'
import * as HTTP_STATUSES from 'http-status'

const crpAxios = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
  headers: {
    Authorization: 'Basic ' + btoa('admin:admin'),
  },
})

crpAxios.interceptors.request.use((config) => {
  return config
})

crpAxios.interceptors.response.use(
  (response) => {
    return {
      success: true,
      ...response.data,
    }
  },
  (error) => {
    if (error.response.status === HTTP_STATUSES.FORBIDDEN) {
      /** Handle API Error */
    }
    return Promise.reject({
      ...error,
      intercepted: true,
      message: error.response.data?.message,
    })
  }
)

export default crpAxios
