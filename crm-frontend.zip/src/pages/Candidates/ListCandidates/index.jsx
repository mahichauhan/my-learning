import React from 'react'
import {Button, Col, Typography} from 'antd'
import {ControlOutlined} from '@ant-design/icons'
import CrpSearchBar from '../../../components/CrpSearchBar'
import {CrpTable, CrpCard} from '../../../components'
import {
  SearchContainer,
  StyledRow,
  StyledUl,
} from './styles'
import listCandidates from '../../../assets/dummy-data/candidates/listCandidates.json'
import listCandidatesColumnMeta from './columnMeta'

const ListCandidates = () => {
  return (
    <>
      <StyledRow>
        <SearchContainer span={10}>
          <CrpSearchBar
            placeholder="Search Candidate"
            buttonType="primary"
          />
        </SearchContainer>
        <Col offset={11} span={2}>
          <Button type="text">
            <ControlOutlined />
            <Typography.Text>APPLY FILTERS</Typography.Text>
          </Button>
        </Col>
      </StyledRow>
      <StyledRow>
        <Col span={24}>
          <CrpCard width="auto">
            <CrpTable
              dataSource={listCandidates}
              title="All Candidates"
              columns={listCandidatesColumnMeta}
              pageSize={10}
              actionList={
                <StyledUl>
                  <li>
                    <Button type="link">
                      Edit Details
                    </Button>
                  </li>
                  <li>
                    <Button type="link">Delete</Button>
                  </li>
                </StyledUl>
              }
            />
          </CrpCard>
        </Col>
      </StyledRow>
    </>
  )
}

export default ListCandidates
