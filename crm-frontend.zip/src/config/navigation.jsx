// eslint-disable-next-line import/named
import icons from '../components/icons/index'
import APP_ROUTES from './app.routes'
import constants from './constants'

const {
  HomeIcon,
  Candidatesicon,
  CampusIcon,
  OpenJobsIcon,
  JobBoardIcon,
  InterviewIcon,
  ReportIcon,
} = icons

const Navigation = {
  HR: [
    {
      id: 1,
      title: 'Your Dashboard',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.DASHBOARD,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <HomeIcon />,
      type: constants.NAVIGATION_TYPE.SIDER,
    },
    {
      id: 2,
      title: 'Add New Campus',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.CAMPUSES.ROOT +
        APP_ROUTES.HR_MODULE.CAMPUSES.ADD,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <CampusIcon />,
      type: constants.NAVIGATION_TYPE.SIDER,
    },
    {
      id: 3,
      title: 'Manage Candidates',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.CANDIDATES.ROOT,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <Candidatesicon />,
      type: constants.NAVIGATION_TYPE.SIDER,
    },
    {
      id: 4,
      title: 'Manage Job Board',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.JOBS.ROOT +
        APP_ROUTES.HR_MODULE.JOBS.BOARD,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <JobBoardIcon />,
      type: constants.NAVIGATION_TYPE.SIDER,
    },
    {
      id: 5,
      title: 'Add an Open Job',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.JOBS.ROOT +
        APP_ROUTES.HR_MODULE.JOBS.ADD,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <OpenJobsIcon />,
      type: constants.NAVIGATION_TYPE.SIDER,
    },
    {
      id: 6,
      title: 'Manage Interviews',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.INTERVIEWS.ROOT,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <InterviewIcon />,
      type: constants.NAVIGATION_TYPE.SIDER,
    },
    {
      id: 7,
      title: 'Reports',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.REPORTS,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <ReportIcon />,
      type: constants.NAVIGATION_TYPE.SIDER,
    },
    {
      id: 7,
      title: 'Profile',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.USERS.PROFILE,
      type: constants.NAVIGATION_TYPE.USER_MENU,
    },
  ],
}

export default Navigation
