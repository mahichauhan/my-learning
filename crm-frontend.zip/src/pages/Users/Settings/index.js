import HrSettings from './HrSettings'

export default HrSettings
