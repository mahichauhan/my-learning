import React from 'react'
import {Layout} from 'antd'
import PropTypes from 'prop-types'
import LayoutContent from './styles'
import Header from './Header'
import Sider from './Sider'

const AppLayout = ({children}) => (
  <Layout style={{minHeight: '968px'}}>
    <Sider />
    <Layout>
      <Header />
      <LayoutContent>{children}</LayoutContent>
    </Layout>
  </Layout>
)

AppLayout.propTypes = {
  children: PropTypes.elementType.isRequired,
}

export default AppLayout
