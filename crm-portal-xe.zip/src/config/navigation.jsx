// eslint-disable-next-line import/named
import icons from '../components/icons/index'
import APP_ROUTES from './app.routes'

const {
  HomeIcon,
  Candidatesicon,
  CampusIcon,
  OpenJobsIcon,
  JobBoardIcon,
  InterviewIcon,
  ReportIcon,
} = icons

const Navigation = {
  HR: [
    {
      id: 1,
      title: 'Dashboard',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.DASHBOARD,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <HomeIcon />,
    },
    {
      id: 2,
      title: 'Add New Campus',
      to:
        APP_ROUTES.HR_MODULE.ROOT +
        APP_ROUTES.HR_MODULE.ADDCAMPUS,
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <CampusIcon />,
    },
    {
      id: 3,
      title: 'Manage Candidates',
      to: 'add-campus',
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <Candidatesicon />,
    },
    {
      id: 4,
      title: 'Manage Job Board',
      to: 'add-campus',
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <JobBoardIcon />,
    },
    {
      id: 5,
      title: 'Add Open Jobs',
      to: 'add-campus',
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <OpenJobsIcon />,
    },
    {
      id: 6,
      title: 'Manage Interviews',
      to: 'add-campus',
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <InterviewIcon />,
    },
    {
      id: 7,
      title: 'Reports',
      to: 'add-campus',
      // eslint-disable-next-line react/react-in-jsx-scope
      icon: <ReportIcon />,
    },
  ],
}

export default Navigation
