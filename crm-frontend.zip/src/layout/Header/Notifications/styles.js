import styled from 'styled-components'
import theme from '../../../config/theme'

export const NotficationListItem = styled('li')({
  marginBottom: '1.5rem',

  '.xebiacrp-typography': {
    fontSize: theme.pxToRem(14),
    color: theme.darkGrey,
    marginBottom: theme.pxToRem(-6),

    '&.activity-time': {
      fontSize: theme.pxToRem(12),
      fontStyle: 'italic',
      color: theme.grey,
    },
  },

  '.xebiacrp-btn-link': {
    fontSize: theme.pxToRem(14),
    padding: 0,
    height: 'inherit',

    span: {
      textDecoration: 'underline',
    },
  },
})
