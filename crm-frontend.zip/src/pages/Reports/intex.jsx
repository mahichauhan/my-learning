import React from 'react'
import {Col, Form, Typography, Anchor} from 'antd'
import {CrpCard} from '../../components'

import StyledRow, {AnchorStyled} from './styled'

const {Title, Paragraph} = Typography
const {Link} = Anchor

const Reports = () => {
  const hide = true
  return (
    <StyledRow gutter={[24, 24]}>
      {hide &&
        [...new Array(8)].map((i) => (
          <Col span={8} key={i}>
            <CrpCard width="auto">
              <Title level={5} type="secondary">
                Candidates hired vs Open positions
              </Title>
              <Paragraph>
                <AnchorStyled bounds={10}>
                  <Link
                    href="#components-anchor-demo-basic"
                    title="Download report"
                  />
                </AnchorStyled>
              </Paragraph>
            </CrpCard>
          </Col>
        ))}
    </StyledRow>
  )
}

export default Reports
