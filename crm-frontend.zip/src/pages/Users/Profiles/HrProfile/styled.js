import {Row} from 'antd'
import styled from 'styled-components'
import theme from '../../../../config/theme'

export const StyledRow = styled(Row)({
  fontSize: theme.pxToRem(14),
  paddingLeft: (props) => props.paddingLeft || 0,
  marginBottom: (props) => props.marginBottom || '0.7rem',

  h2: {
    color: theme.darkGrey,
    fontSize: theme.pxToRem(16),
    textTransform: 'uppercase',
  },

  h3: {
    color: theme.darkGrey,
    fontSize: theme.pxToRem(14),
  },
})
