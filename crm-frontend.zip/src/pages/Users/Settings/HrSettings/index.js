import React from 'react'
import {
  Col,
  Typography,
  Anchor,
  Avatar,
  Button,
  Switch,
  Space,
} from 'antd'
import {
  CrpCard,
  IconButton,
  CrpTable,
  CrpInputField,
} from '../../../../components'
import {
  FormOutlined,
  SearchOutlined,
} from '@ant-design/icons'
import StyledRow, {
  StyledUl,
  ParagraphStyled,
} from './styled'
import User from '../../../../assets/images/avatars/user1.png'
import listCandidates from '../../../../assets/dummy-data/candidates/listCandidates.json'
import listCandidatesColumnMeta from './columnMeta'

const {Title, Paragraph} = Typography
const {Link} = Anchor

const HrSettings = () => {
  const hide = true
  return (
    <>
      <StyledRow gutter={[24, 24]}>
        <Col span={12} key={'avtar'}>
          <CrpCard width="auto">
            <div className="usersetting">
              <Title level={5} type="secondary">
                Notification settings
              </Title>
              <IconButton
                incons={FormOutlined}
                size="large">
                Edit
              </IconButton>
            </div>
            <ParagraphStyled>
              Choose Profile Avatar
            </ParagraphStyled>
            <div className="user-avatar">
              {[...new Array(10)].map((item) => (
                <Avatar
                  src={User}
                  key={item}
                  title="Ant User"
                  size={72}
                  className="crpavatar"
                />
              ))}
            </div>
            <div>
              <Paragraph>
                <span>
                  <strong>Email:</strong>
                </span>{' '}
                garima.mohan@xebia.com
              </Paragraph>
              <Paragraph>
                <span>
                  <strong>Mobile:</strong>
                </span>
                +91 98640 98640
              </Paragraph>
            </div>
          </CrpCard>
        </Col>
        <Col span={12} key={'notification'}>
          <CrpCard width="auto">
            <Title level={5} type="secondary">
              Notification settings
            </Title>
            {[...new Array(6)].map((item) => (
              <div className="usersetting" key={item}>
                <ParagraphStyled>
                  Notify when a New Candidate signs up
                </ParagraphStyled>

                <Switch size="small" checked />
              </div>
            ))}
          </CrpCard>
        </Col>
      </StyledRow>
      <StyledRow gutter={[14, 6]}>
        <Col key={'last'} span={24} flex="auto">
          <CrpCard width="auto">
            <div className="table-header">
              <div style={{flexGrow: 6}}>
                <Title level={5} type="secondary">
                  Manage interviewers
                </Title>
              </div>
              <div style={{flexGrow: 4}}>
                <CrpInputField type="text" />
              </div>
              <div
                style={{flexGrow: 4, textAlign: 'center'}}>
                <IconButton incons={SearchOutlined} shadow>
                  Search
                </IconButton>
              </div>
              <div style={{flexGrow: 4, textAlign: 'end'}}>
                <Button
                  className="add-member"
                  type="primary">
                  Add new interviewer
                </Button>
              </div>
            </div>
            <CrpTable
              dataSource={listCandidates}
              title="Manage interviewers"
              columns={listCandidatesColumnMeta}
              pageSize={10}
              actionList={
                <StyledUl>
                  <li>
                    <Button type="link">
                      Edit Details
                    </Button>
                  </li>
                  <li>
                    <Button type="link">Delete</Button>
                  </li>
                </StyledUl>
              }
            />
          </CrpCard>
        </Col>
      </StyledRow>
    </>
  )
}

export default HrSettings
