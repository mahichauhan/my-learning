import React from 'react'

const CampusIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="18.881"
    height="18.881"
    viewBox="0 0 18.881 18.881">
    <defs />
    <g transform="translate(0 0)">
      <path
        className="nav-icon-fill"
        fill="#fff"
        d="M25.781,14.073H6.9V11.933L16.34,8.7l9.44,3.233Zm-18.074-.83H24.952v-.721L16.34,9.574,7.707,12.522Z"
        transform="translate(-6.9 -8.7)"
      />
    </g>
    <g transform="translate(0 14.993)">
      <path
        className="nav-icon-fill"
        fill="#fff"
        d="M25.781,77.588H6.9V75.753A2.049,2.049,0,0,1,8.949,73.7H23.731a2.049,2.049,0,0,1,2.049,2.053v1.835Zm-18.074-.83H24.952V75.731a1.243,1.243,0,0,0-1.243-1.245H8.949a1.243,1.243,0,0,0-1.243,1.245S7.707,76.758,7.707,76.758Z"
        transform="translate(-6.9 -73.7)"
      />
    </g>
    <g transform="translate(2.687 4.571)">
      <path
        className="nav-icon-fill"
        fill="#fff"
        d="M22.5,40.669H19.2V29.5h3.3V40.669Zm-2.468-.886h1.66v-9.4H20.03Z"
        transform="translate(-19.2 -29.5)"
      />
    </g>
    <g transform="translate(12.896 4.571)">
      <path
        fill="#fff"
        className="nav-icon-fill"
        d="M69.4,40.669H66.1V29.5h3.3Zm-2.49-.886h1.66v-9.4h-1.66Z"
        transform="translate(-66.1 -29.5)"
      />
    </g>
    <g transform="translate(7.791 4.571)">
      <path
        fill="#fff"
        className="nav-icon-fill"
        d="M69.4,40.669H66.1V29.5h3.3Zm-2.49-.886h1.66v-9.4h-1.66Z"
        transform="translate(-66.1 -29.5)"
      />
    </g>
  </svg>
)

export default CampusIcon
