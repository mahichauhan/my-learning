import { Invoice } from './components';

import './App.css';

function App() {
  return (
    <Invoice />
  );
}

export default App;
