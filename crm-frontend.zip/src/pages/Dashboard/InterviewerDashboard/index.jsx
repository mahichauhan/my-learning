import React from 'react'

import styled from 'styled-components'
// import theme from '../../../config/Theme'

const StyledInterviewerDashboard = styled('div')`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
`

const InterviewerDashboard = () => (
  <StyledInterviewerDashboard>
    <h2>Interviewer Dashboard</h2>
  </StyledInterviewerDashboard>
)

export default InterviewerDashboard
