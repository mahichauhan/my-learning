import React from 'react'
import {Button, Popover, Typography} from 'antd'
import theme from '../../../../config/theme'

const listCandidatesColumnMeta = [
  {
    title: 'Users Name',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Department',
    dataIndex: 'cgpa',
    key: 'cgpa',
    render: () => 'Technical',
  },
  {
    title: 'Designation',
    dataIndex: 'courseSpecialization',
    key: 'courseSpecialization',
    render: () => 'Technical',
  },
  {
    title: 'Role',
    dataIndex: 'positionApplied',
    key: 'positionApplied',
    render: () => 'Interviewer',
  },
  {
    title: 'Designation',
    dataIndex: 'interviewRound',
    key: 'interviewRound',
    render: () => 'L1 Interview',
  },
  {
    title: 'Interviewer Type',
    dataIndex: 'nextInterview',
    key: 'nextInterview',
    render: () => 'L2 Interviewer',
  },
]

export default listCandidatesColumnMeta
