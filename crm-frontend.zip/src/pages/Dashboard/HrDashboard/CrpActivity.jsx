import React from 'react'
import {CrpCard} from '../../../components'
import {Timeline, Typography, Col, Row} from 'antd'
import {
  ClockCircleOutlined,
  LoadingOutlined,
} from '@ant-design/icons'
import theme from '../../../config/theme'

const CrpActivity = (props) => (
  <>
    <CrpCard width="auto" borderRadius={4}>
      <Typography.Text style={{color: 'black'}}>
        {props.activityHead}
      </Typography.Text>
      <div style={{marginTop: 40}}>
        <Timeline>
          {props.data.map((itm, idx) => (
            <Col
              key={idx}
              style={{
                flexDirection: 'row-reverse',
              }}>
              <Timeline.Item
                style={{
                  color: theme.darkGrey,
                  fontSize: theme.pxToRem(14),
                }}>
                {itm.title}
                <div>
                  <Typography.Text
                    style={{
                      color: theme.grey,
                      fontSize: theme.pxToRem(12),
                      fontStyle: 'italic',
                    }}>
                    {itm.time}
                  </Typography.Text>
                </div>
                <Typography.Text
                  style={{
                    color: theme.purpleColor,
                    fontSize: theme.pxToRem(12),
                  }}>
                  {itm.desc}
                </Typography.Text>
              </Timeline.Item>
            </Col>
          ))}
        </Timeline>
        <Typography.Title
          style={{
            color: theme.purpleColor,
            fontSize: theme.pxToRem(12),
            textAlign: 'center',
          }}>
          {'More'}
        </Typography.Title>
      </div>
    </CrpCard>
  </>
)

export default CrpActivity
