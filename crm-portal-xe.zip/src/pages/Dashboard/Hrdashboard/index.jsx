import React from 'react'

import styled from 'styled-components'
// import theme from '../../../config/Theme'

const StyledHrDashboard = styled('div')`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
`

const HrDashboard = () => (
  <StyledHrDashboard>
    <h2>Hr dashboar</h2>
  </StyledHrDashboard>
)

export default HrDashboard
