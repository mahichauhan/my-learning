import {combineReducers} from 'redux'
import AlertReducer from './AlertReducer'
import UserReducer from './UserReducer'

const RootReducer = combineReducers({
  ALERT: AlertReducer,
  USER: UserReducer,
})

export default RootReducer
