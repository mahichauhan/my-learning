import React from 'react'
import {BrowserRouter as Router} from 'react-router-dom'
import InterviewDashboard from '../../pages/Dashboard/InterviewerDashboard'
import APP_ROUTES from '../../config/app.routes'
import PrivateRoute from '../../routes/PrivateRoute'

const {INTERVIEWER_MODULE} = APP_ROUTES

const InterviewerModule = () => (
  <Router basename={INTERVIEWER_MODULE.ROOT}>
    <PrivateRoute
      exact
      path={INTERVIEWER_MODULE.DASHBOARD}
      component={InterviewDashboard}
    />
  </Router>
)

export default InterviewerModule
