import {actionType} from './actionTypes'

// eslint-disable-next-line import/prefer-default-export
export const setLoggedInUser = (payload) => ({
  type: actionType.UserActionType
    .SET_LOGGED_IN_USER_SAGA_WATCHERS,
  payload,
})

export const setAlert = (payload) => {
  return {
    type: actionType.AlertActionType.ADD_ALERT,
    payload,
  }
}

export const removetAlert = () => ({
  type: actionType.AlertActionType.REMOVE_ALERT,
})
